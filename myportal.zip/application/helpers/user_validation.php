<?php

	function email_validation($email)
	{
		$con = &get_instance();
		$user_array = array('admin', 'teacher', 'parent', 'student', 'accountant');
		$size = sizeof($user_array);
		
		for($i = 0; $i < $size; $i++)
		{
			$where = array('email' => $email);
			$num_rows = $con->db->get_where($user_array[$i], $where)->num_rows();
			if($num_rows > 0)
			{
				return 0;
			}
		}
		return 1;
	}
	
	function email_validation_for_edit($email, $id, $type)
	{
		$con = &get_instance();
		$user_array = array('admin', 'teacher', 'parent', 'student', 'accountant');
		$size = sizeof($user_array);
		for($i = 0; $i < $size; $i++){
			if($type == $user_array[$i]){
				$where = array('email' => $email);
				$num_rows = $con->db->get_where_not_in($user_array[$i], $user_array[$i].'_id', $id, $where)->num_rows();
				if($num_rows > 0)
				{
					return 0;
				}else
				{
					return 1;
				}
			}
		}
	}
	
	// Section duplication on create
	function duplication_of_section_on_create($class_id, $section_name)
	{
		$con = &get_instance();
		$data = array(
			'class_id' => $class_id,
			'name' => $section_name
		);
		
		$num_rows = $con->db->get_where('section', $data)->num_rows();
		if($num_rows == 0)
		{
			return 1;
		}
		else if($num_rows > 1)
		{
			return 0;
		}
	}
	
	// section duplication on edit
	function duplication_of_section_on_edit($section_id, $class_id, $section_name)
	{
		$con = &get_instance();
		$data = array(
			'class_id' => $class_id,
			'name' => $section_name
		);
		
		$num_rows = $con->db->get_where_not_in('section', 'section_id', $section_id, $data)->num_rows();
		if($num_rows == 0)
		{
			return 1;
		}
		else if($num_rows > 1)
		{
			return 0;
		}
	}
	
	// class routine duplication on create
	function duplication_of_class_routine_on_create($data)
	{
		$con = &get_instance();
		$num_rows = $con->db->get_where('class_routine', $data)->num_rows();
		if($num_rows == 0)
		{
			return 1;
		}
		else if($num_rows > 1)
		{
			return 0;
		}
	}
	
	// class routine duplication on edit
	function duplication_of_class_routine_on_edit($data, $class_routine_id)
	{
		$con = &get_instance();
		$num_rows = $con->db->get_where_not_in('class_routine', 'class_routine_id', $class_routine_id, $data)->num_rows();
		if($num_rows == 0)
		{
			return 1;
		}
		else if($num_rows > 1)
		{
			return 0;
		}
	}
	
	//student id duplication on insert
	function code_validation_insert($student_code)
	{
		$con = &get_instance();
		$num_rows = $con->db->get_where('student', array('student_code' => $student_code))->num_rows();
		if($num_rows == 0){
			return true;
		}
		else if($num_rows > 0){
			return false;
		}
	}
	
	//student id duplication in update
	function code_validation_update($student_code, $student_id)
	{
		$con = &get_instance();
		$where = array('student_id' => $student_id, 'student_code' => $student_code);
		$num_rows = $con->db->get_where('student', $where)->num_rows();
		if($num_rows > 0){
			return true;
		}
		else if($num_rows == 0){
			return false;
		}
	}
	