<?php

class Login extends Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
        $this->load->library('session');
		
		//	Cache control
        header('Last-Modified: '.gmdate("D, d M Y H:i:s").' GMT');
        header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        header('Pragma: no-cache');
        header("Expires: Mon, 26 Jul 2010 05:00:00 GMT");
	}
	
	//	Default function, redirects to Login page if no Admin logged in yet
	public function index()
	{
		if ($this->session->userdata('admin_login') == 1)
			redirect(base_url() . 'index.php?admin/dashboard', 'refresh');
		
		if ($this->session->userdata('accountant_login') == 1)
            redirect(base_url() . 'index.php?accountant/dashboard', 'refresh');
		
		if ($this->session->userdata('librarian_login') == 1)
			redirect(base_url() . 'index.php?librarian/dashboard', 'refresh');
		
		if ($this->session->userdata('teacher_login') == 1)
			redirect(base_url() . 'index.php?teacher/dashboard', 'refresh');
		
		if ($this->session->userdata('parent_login') == 1)
			redirect(base_url() . 'index.php?parents/dashboard', 'refresh');
		
		if ($this->session->userdata('student_login') == 1)
            redirect(base_url() . 'index.php?student/dashboard', 'refresh');
		
		$this->load->view('portal/login');
	}
	
	/*** LOGIN FUNCTION ***/
	public function validate_login()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$credential = array('email' => $email, 'password' => $password);
		
		//	Checking login credential for Admin
		$query = $this->db->get_where('admin', $credential);
		if($query->num_rows() > 0)
		{
			$row = $query->row();
			$this->session->set_userdata('admin_login', '1');
			$this->session->set_userdata('admin_id', $row->admin_id);
			$this->session->set_userdata('login_user_id', $row->admin_id);
			$this->session->set_userdata('name', $row->name);
			$this->session->set_userdata('login_type', 'admin');
			redirect(base_url() . 'index.php?admin/dashboard', 'refresh');
		}
		
		//	Checking login credential for Accountant
		$query = $this->db->get_where('accountant', $credential);
		if($query->num_rows() > 0)
		{
			$row = $query->row();
			$this->session->set_userdata('accountant_login', '1');
			$this->session->set_userdata('accountant_id', $row->accountant_id);
			$this->session->set_userdata('login_user_id', $row->accountant_id);
			$this->session->set_userdata('name', $row->name);
			$this->session->set_userdata('login_type', 'accountant');
			redirect(base_url() . 'index.php?accountant/dashboard', 'refresh');
		}
		
		//	Checking login credential for Librarian
		$query = $this->db->get_where('librarian', $credential);
		if($query->num_rows() > 0)
		{
			$row = $query->row();
			$this->session->set_userdata('librarian_login', '1');
			$this->session->set_userdata('librarian_id', $row->librarian_id);
			$this->session->set_userdata('login_user_id', $row->librarian_id);
			$this->session->set_userdata('name', $row->name);
			$this->session->set_userdata('login_type', 'librarian');
			redirect(base_url() . 'index.php?librarian/dashboard', 'refresh');
		}
		
		//	Checking login credential for Teacher
		$query = $this->db->get_where('teacher', $credential);
		if($query->num_rows() > 0)
		{
			$row = $query->row();
			$this->session->set_userdata('teacher_login', '1');
			$this->session->set_userdata('teacher_id', $row->teacher_id);
			$this->session->set_userdata('login_user_id', $row->teacher_id);
			$this->session->set_userdata('name', $row->name);
			$this->session->set_userdata('login_type', 'teacher');
			redirect(base_url() . 'index.php?teacher/dashboard', 'refresh');
		}
		
		// Checking login credential for parent
		$query = $this->db->get_where('parent', $credential);
		if($query->num_rows() > 0)
		{
			$row = $query->row();
			$this->session->set_userdata('parent_login', '1');
			$this->session->set_userdata('parent_id', $row->parent_id);
			$this->session->set_userdata('login_user_id', $row->parent_id);
			$this->session->set_userdata('name', $row->name);
			$this->session->set_userdata('login_type', 'parent');
			redirect(base_url() . 'index.php?parents/dashboard', 'refresh');
		}
		
		// Checking login credential for student
		$query = $this->db->get_where('student', $credential);
		if($query->num_rows() > 0)
		{
			$row = $query->row();
			$this->session->set_userdata('student_login', '1');
			$this->session->set_userdata('student_id', $row->student_id);
			$this->session->set_userdata('login_user_id', $row->student_id);
			$this->session->set_userdata('name', $row->name);
			$this->session->set_userdata('login_type', 'student');
			redirect(base_url() . 'index.php?student/dashboard', 'refresh');
		}
		
		$this->session->set_flashdata('login_error', 'Invalid Login');
		redirect(base_url() . 'index.php?login', 'refresh');
	}
	
	/*** PASSWORD RESET BY EMAIL ***/
	public function forgot_password()
	{
		$this->load->view('portal/forgot_password');
	}
	
	public function reset_password()
	{
		$email = $this->input->post('email');
		$reset_account_type     = '';
		//resetting user password here
		$new_password           =   substr( md5( rand(100000000,20000000000) ) , 0,7);
		
		// Checking credential for admin
		$query = $this->db->get_where('admin' , array('email' => $email));
		if ($query->num_rows() > 0)
		{
			$reset_account_type     =   'admin';
			//$this->db->where('email' , $email);
			//$this->db->update('admin' , array('password' => $new_password));
			// send new password to user email
			//$this->email_model->password_reset_email($new_password , $reset_account_type , $email);
			$this->session->set_flashdata('reset_success', 'Please check your Email for new Password');
			redirect(base_url() . 'index.php?login/forgot_password', 'refresh');
		}
		
		$this->session->set_flashdata('reset_error', 'Password Reset was Failed');
		redirect(base_url() . 'index.php?login/forgot_password', 'refresh');
	}
	
	/*** LOGOUT FUNCTION ***/
	public function logout()
	{
		$this->session->sess_destroy();
		$this->session->set_flashdata('logout_notification', 'Logged Out');
		redirect(base_url().'index.php?login', 'refresh');
	}

}