<?php

class Parents extends Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->library('session');
		
		//	Cache control
		header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
		header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		header('Pragma: no-cache');
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	}
	
	//	Default function, redirects to Login page if no Parent logged in yet
	public function index()
	{
		if($this->session->userdata('parent_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		if($this->session->userdata('parent_login') == 1)
			redirect(base_url() . 'index.php?parents/dashboard', 'refresh');
	}
	
	/*** PARENT DASHBOARD ***/
	function dashboard()
	{
		if($this->session->userdata('parent_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'dashboard';
		$page_data['page_title'] = 'Parent Dashboard';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** TEACHERS ***/
	function teachers($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('parent_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'teachers';
		$page_data['page_title'] = 'Teachers';
		$page_data['teachers']   = $this->db->get('teacher')->result_array();
		$this->load->view('portal/index', $page_data);
	}
	
	/*** STUDENT ATTENDANCE ***/
	function attendance_report($student_id = '')
	{
		if($student_id != '')
		{
			$student_name = $this->db->get_where('student', array('student_id' => $student_id))->row()->name;
			$page_data['month']			= date('m');
			$page_data['page_name']		= 'attendance_report';
			$page_data['page_title']	= 'Attendance Report of '.ucwords($student_name);
			$page_data['student_id']	= $student_id;
			$this->load->view('portal/index', $page_data);
		}
	}
	
	function attendance_report_selector($student_id = '')
	{
		if($student_id != '')
		{
			$running_year 		=   $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			$array = array('student_id' => $student_id, 'year' => $running_year);
			$class_id               = $this->db->get_where('enroll', $array)->row()->class_id;
			$section_id             = $this->db->get_where('enroll', $array)->row()->section_id;
			
			$data['class_id']		= $class_id;
			$data['section_id']		= $section_id;
			$data['month']			= $this->input->post('month');
			$data['sessional_year']	= $this->input->post('sessional_year');
			$data['student_id']     = $student_id;
			redirect(base_url() . 'index.php?parents/attendance_report_view/'.$data['class_id'].'/'.$data['section_id'].'/'.$data['month'].'/'.$data['sessional_year'].'/'.$data['student_id'], 'refresh');
		}
	}
	
	function attendance_report_view($class_id = '', $section_id = '', $month = '', $sessional_year = '', $student_id = '')
	{
		if($this->session->userdata('parent_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$student_name					= $this->db->get_where('student', array('student_id' => $student_id))->row()->name;
		$class_name						= $this->db->get_where('class', array('class_id' => $class_id))->row()->name;
		$section_name					= $this->db->get_where('section', array('section_id' => $section_id))->row()->name;
		$page_data['student_id']		= $student_id;
		$page_data['class_id']			= $class_id;
		$page_data['section_id']		= $section_id;
		$page_data['month']				= $month;
		$page_data['sessional_year']	= $sessional_year;
		$page_data['page_name']			= 'attendance_report_view';
		$page_data['page_title']		= 'Attendance Report of '.ucwords($student_name);
		$this->load->view('portal/index', $page_data);
	}
	
	function attendance_report_print_view($class_id ='', $section_id = '', $month = '', $sessional_year = '')
	{
		if($this->session->userdata('parent_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['class_id']			= $class_id;
		$page_data['section_id']		= $section_id;
		$page_data['month']				= $month;
		$page_data['sessional_year']	= $sessional_year;
		$this->load->view('portal/parents/attendance_report_print_view', $page_data);
	}
	
	/*** ACADEMIC SYLLABUS ***/
	function academic_syllabus($student_id = '')
	{
		if($this->session->userdata('parent_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'academic_syllabus';
		$page_data['page_title'] = 'Academic Syllabus';
		$page_data['student_id']   = $student_id;
		$this->load->view('portal/index', $page_data);
	}
	
	function download_academic_syllabus($academic_syllabus_code)
	{
		set_time_limit(0);
		
		$file_name = $this->db->get_where('academic_syllabus', array(
			'academic_syllabus_code' => $academic_syllabus_code
		))->row()->file_name;
		
		$file = "uploads/syllabus/".$file_name;
		
		force_download($file, $file_name);
	}
	
	/*** CLASS ROUTINE ***/
	function class_routine($student_id = '')
	{
		if($this->session->userdata('parent_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'class_routine';
		$page_data['student_id']  =   $student_id;
		$page_data['page_title'] = 'Class Routine';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** EXAM RESULTS ***/
	function results($param1 = '')
	{
		if($this->session->userdata('parent_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'results';
		$page_data['page_title'] = 'Exam Results';
		$page_data['student_id'] = $param1;
		$this->load->view('portal/index', $page_data);
	}
	
	function get_year_exam($year)
	{
		$exams = $this->db->get_where('exam', array('year' => $year, 'status' => 'available'))->result_array();
		
		echo '<option value=""> Select </option>';
		
		foreach($exams as $row)
		{
			echo '<option value="' . $row['exam_id'] . '">' . ucwords($row['name']) .' ('. $row['date'] . ') </option>';
		}
	}
	
	function get_student_exam_marks($exam_id, $student_id)
	{
		$account_type				= $this->session->userdata('login_type');
		$page_data['student_id']	= $student_id;
		$page_data['exam_id']		= $exam_id;
		$page_data['year']			= $this->db->get_where('exam', array('exam_id' => $exam_id))->row()->year;
		$page_name					= 'student_marksheet';
		$this->load->view('portal/'.$account_type.'/'.$page_name.'.php', $page_data);
	}
	
	/*** LIBRARY/BOOKS ***/
	function book($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('parent_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'book';
		$page_data['page_title'] = 'Library Books';
		$page_data['books']      = $this->db->get('book')->result_array();
		$this->load->view('portal/index', $page_data);
	}
	
	/*** INVOICES / PAYMENT WITH STATUS ***/
	function invoice($student_id = '')
	{
		$parent_profile = $this->db->get_where('parent', array(
			'parent_id' => $this->session->userdata('parent_id')
		))->row();
		
		$page_data['page_name']  = 'invoice';
		$page_data['page_title'] = 'Students Invoice / Payment';
		$page_data['student_id'] = $student_id;
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE OWN PROFILE AND CHANGE PASSWORD ***/
	function manage_profile($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('parent_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Update Profile
		if($param1 == 'update_profile_info')
		{
			$data['name']  = $this->input->post('name');
			$data['email'] = $this->input->post('email');
			
			$parent_id = $this->session->userdata('parent_id');
			
			$validation = email_validation_for_edit($data['email'], $parent_id, 'parent');
			if($validation == 1)
			{
				$where = array('parent_id' => $this->session->userdata('parent_id'));
				$this->db->update('parent', $where, $data);
                $this->session->set_flashdata('flash_message', 'Account Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			redirect(base_url() . 'index.php?parents/manage_profile/', 'refresh');
		}
		//	Change Password
		if($param1 == 'change_password')
		{
			$data['password']		= $this->input->post('password');
			$data['new_password']	= $this->input->post('new_password');
			$data['cnew_password']	= $this->input->post('cnew_password');
			
			$current_password = $this->db->get_where('parent', array(
				'parent_id' => $this->session->userdata('parent_id')
			))->row()->password;
			if($current_password == $data['password'] && $data['new_password'] == $data['cnew_password'])
			{
				$where = array('parent_id' => $this->session->userdata('parent_id'));
				$this->db->update('parent', $where, array(
					'password' => $data['new_password']
				));
				$this->session->set_flashdata('flash_message', 'Password Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'Password Mismatch');
			}
			redirect(base_url() . 'index.php?parents/manage_profile/', 'refresh');
		}
		
		$page_data['page_name']  = 'manage_profile';
		$page_data['page_title'] = 'Manage Profile';
		$page_data['edit_data']  = $this->db->get_where('parent', array(
			'parent_id' => $this->session->userdata('parent_id')
		))->result_array();
		$this->load->view('portal/index', $page_data);
	}
	

}