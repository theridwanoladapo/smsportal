<?php

class Admin extends Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->library('session');
		
		//	Cache control
		header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
		header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		header('Pragma: no-cache');
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	}
	
	//	Default function, redirects to Login page if no Admin logged in yet
	public function index()
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		if($this->session->userdata('admin_login') == 1)
			redirect(base_url() . 'index.php?admin/dashboard', 'refresh');
	}
	
	/*** ADMIN DASHBOARD ***/
	function dashboard()
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'dashboard';
		$page_data['page_title'] = 'Admin Dashboard';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE STUDENTS ***/
	function student_add()
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'student_add';
		$page_data['page_title'] = 'Admit Student';
		$this->load->view('portal/index', $page_data);
	}
	
	function student_information($class_id = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  	= 'student_information';
		$page_data['page_title'] 	= 'Student Information';
		$page_data['class_id'] 	= $class_id;
		$this->load->view('portal/index', $page_data);
	}
	
	function student_profile($student_id)
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'student_profile';
		$page_data['page_title'] = 'Student Profile';
		$page_data['student_id']  = $student_id;
		$this->load->view('portal/index', $page_data);
	}
	
	function get_students_by_class($class_id = '')
	{
		$account_type				= $this->session->userdata('login_type');
		$page_name					= 'student_by_class';
		$page_data['class_id']		= $class_id;
		$this->load->view('portal/'.$account_type.'/'.$page_name.'.php', $page_data);
	}
	
	function student($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
		//	Create Student
		if($param1 == 'create')
		{
			$data['name']		= $this->input->post('name');
			$data['parent_id']	= $this->input->post('parent_id');
			$data['birthday']	= $this->input->post('birthday');
			$data['gender']		= $this->input->post('gender');
			$data['address']	= $this->input->post('address');
			$data['phone']		= $this->input->post('phone');
			if($this->input->post('student_code') != null){
				$data['student_code'] = $this->input->post('student_code');
				$code_validation = code_validation_insert($data['student_code']);
				if(!$code_validation){
					$this->session->set_flashdata('error_message', 'This ID Number is not available');
					redirect(base_url() . 'index.php?admin/student_add/', 'refresh');
				}
			}
			$data['email']        = $this->input->post('email');
			$data['password']     = $this->input->post('password');
			
			$validation = email_validation($data['email']);
			if($validation == 1)
			{
				$this->db->insert('student', $data);
				$student_id = $this->db->insert_id();
				
				$data2['enroll_code']	= substr(md5(rand(0, 1000000)), 0, 7);
				$data2['student_id']	= $student_id;
				$data2['class_id']		= $this->input->post('class_id');
				$data2['section_id']	= $this->input->post('section_id');
				$data2['roll']			= $this->input->post('roll');
				$data2['date_added']	= strtotime(date("Y-m-d H:i:s"));
				$data2['year']			= $running_year;
				$this->db->insert('enroll', $data2);
				move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/student_image/'.$student_id.'.jpg');
				
				$this->session->set_flashdata('flash_message', 'Data Added Successfully');
				//$this->email_model->account_opening_email('student', $data['email']); //SEND EMAIL ACCOUNT OPENING EMAIL
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			
			redirect(base_url() . 'index.php?admin/student_add/', 'refresh');
		}
		//	Update Student
		if($param1 == 'do_update')
		{
			$data['name']		= $this->input->post('name');
			$data['parent_id']	= $this->input->post('parent_id');
			$data['birthday']	= $this->input->post('birthday');
			$data['gender']		= $this->input->post('gender');
			$data['address']	= $this->input->post('address');
			$data['phone']		= $this->input->post('phone');
			if($this->input->post('student_code') != null){
				$data['student_code'] = $this->input->post('student_code');
				$code_validation = code_validation_update($data['student_code'],$param2);
				if(!$code_validation)
				{
					$this->session->set_flashdata('error_message', 'This ID Number is not available');
					redirect(base_url() . 'index.php?admin/student_information/', 'refresh');
				}
			}
			$data['email']        = $this->input->post('email');
			$data['password']     = $this->input->post('password');
			
			$validation = email_validation_for_edit($data['email'], $param2, 'student');
			if($validation == 1)
			{
				$this->db->update('student', array('student_id' => $param2), $data);
				
				$data2['section_id'] = $this->input->post('section_id');
				$data2['roll'] = ($this->input->post('roll') != null) ? $this->input->post('roll') : null;
				$running_year = $this->db->get_where('settings', array('type'=>'running_year'))->row()->description;
				$where = array('student_id' => $param2, 'year' => $running_year);
				$this->db->update('enroll', $where, array(
					'section_id' => $data2['section_id'],
					'roll' => $data2['roll']
				));
				move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/student_image/'.$param2.'.jpg');
				
				$this->session->set_flashdata('flash_message', 'Data Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			
			redirect(base_url() . 'index.php?admin/student_information/', 'refresh');
		}
	}
	
	function delete_student($student_id = '')
	{
		delete_student($student_id);
		$this->session->set_flashdata('flash_message', 'Student Deleted');
		redirect(base_url() . 'index.php?admin/student_information/', 'refresh');
	}
	
	//	STUDENT PROMOTION	//
	function student_promotion($param1 = '', $param2 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']		= 'student_promotion';
		$page_data['page_title']	= 'Student Promotion';
		$this->load->view('portal/index', $page_data);
	}
	
	function promote($promotion_from, $promotion_to, $running_year, $promotion_year)
	{
		$students_of_promotion_class	=	$this->db->get_where('enroll', array(
												'class_id' => $promotion_from,
												'year' => $running_year
											))->result_array();
		
		foreach($students_of_promotion_class as $row)
		{
			$enroll_data['enroll_code']	= substr(md5(rand(0, 1000000)), 0, 7);
			$enroll_data['student_id']	= $row['student_id'];
			$enroll_data['class_id']	= $this->input->post('promotion_status_'.$row['student_id']);
			$enroll_data['date_added']	= strtotime(date("Y-m-d H:i:s"));
			$enroll_data['year']		= $promotion_year;
			
			$this->db->insert('enroll', $enroll_data);
		}
		
		$this->session->set_flashdata('flash_message', 'New Enrollment Successful');
		redirect(base_url() . 'index.php?admin/student_promotion', 'refresh');
	}
	function get_students_to_promote($promotion_from, $promotion_to, $running_year, $promotion_year)
	{
		$page_data['promotion_from']	=	$promotion_from;
		$page_data['promotion_to']		=	$promotion_to;
		$page_data['running_year']		=	$running_year;
		$page_data['promotion_year']	=	$promotion_year;
		$this->load->view('portal/admin/student_promotion_selector', $page_data);
	}
	
	/*** MANAGE PARENTS ***/
	function parent($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Parent
		if($param1 == 'create')
		{
			$data['name']		= $this->input->post('name');
			$data['email']		= $this->input->post('email');
			$data['password']	= $this->input->post('password');
			$data['phone']		= $this->input->post('phone');
			$data['address']	= $this->input->post('address');
			$data['profession']	= $this->input->post('profession');
			
			$validation = email_validation($data['email']);
			if($validation == 1)
			{
				$this->db->insert('parent', $data);
				$this->session->set_flashdata('flash_message', 'Data Added Successfully');
				//$this->email_model->account_opening_email('parent', $data['email']); //SEND EMAIL ACCOUNT OPENING EMAIL
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			
			redirect(base_url() . 'index.php?admin/parent/', 'refresh');
		}
		//	Edit Parent
		if($param1 == 'edit')
		{
			$data['name']		= $this->input->post('name');
			$data['email']		= $this->input->post('email');
			$data['phone']		= $this->input->post('phone');
			$data['address']	= $this->input->post('address');
			$data['profession']	= ($this->input->post('profession') != null) ? $this->input->post('profession') : null;
			
			$validation = email_validation_for_edit($data['email'], $param2, 'parent');
			if($validation == 1)
			{
				$this->db->update('parent', array('parent_id' => $param2), $data);
				$this->session->set_flashdata('flash_message', 'Data Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			
			redirect(base_url() . 'index.php?admin/parent/', 'refresh');
		}
		//	Delete Parent
		if($param1 == 'delete') 
		{
			$where = array('parent_id' => $param2);
			$this->db->delete('parent', $where);
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/parent/', 'refresh');
		}
		
		$page_data['page_title']	= 'Manage Parents';
		$page_data['page_name']		= 'parent';
		$this->load->view('portal/index', $page_data);
	}

	/*** MANAGE TEACHERS ***/
	function teacher($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Teacher
		if($param1 == 'create') {
			$data['name']			= $this->input->post('name');
			$data['designation']	= $this->input->post('designation');
			$data['birthday']		= $this->input->post('birthday');
			$data['gender']			= $this->input->post('gender');
			$data['address']		= $this->input->post('address');
			$data['phone']			= $this->input->post('phone');
			$data['email']			= $this->input->post('email');
			$data['password']		= $this->input->post('password');
			$links = array();
			$social['linkedin']		= ($this->input->post('linkedin') != null) ? $this->input->post('linkedin') : null;
			$social['facebook']		= ($this->input->post('facebook') != null) ? $this->input->post('facebook') : null;
			$social['twitter']		= ($this->input->post('twitter') != null) ? $this->input->post('twitter') : null;
			array_push($links, $social);
			$data['social_links'] = json_encode($links);
			
			$validation = email_validation($data['email']);
			if($validation == 1)
			{
				$this->db->insert('teacher', $data);
				$teacher_id = $this->db->insert_id();
				move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/teacher_image/'.$teacher_id.'.jpg');
				$this->session->set_flashdata('flash_message', 'Data Added Successfully');
				//$this->email_model->account_opening_email('teacher', $data['email']); //SEND EMAIL ACCOUNT OPENING EMAIL
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			
			redirect(base_url() . 'index.php?admin/teacher/', 'refresh');
		}
		//	Update Teacher
		if($param1 == 'do_update') {
			$data['name']			= $this->input->post('name');
			$data['designation']	= $this->input->post('designation');
			$data['birthday']		= $this->input->post('birthday');
			$data['gender']			= $this->input->post('gender');
			$data['address']		= $this->input->post('address');
			$data['phone']			= $this->input->post('phone');
			$data['email']			= $this->input->post('email');
			$links = array();
			$social['linkedin']		= ($this->input->post('linkedin') != null) ? $this->input->post('linkedin') : null;
			$social['facebook']		= ($this->input->post('facebook') != null) ? $this->input->post('facebook') : null;
			$social['twitter']		= ($this->input->post('twitter') != null) ? $this->input->post('twitter') : null;
			array_push($links, $social);
			$data['social_links'] = json_encode($links);
			
			$validation = email_validation_for_edit($data['email'], $param2, 'teacher');
			if($validation == 1)
			{
				$this->db->update('teacher', array('teacher_id' => $param2), $data);
				move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/teacher_image/'.$param2.'.jpg');
				$this->session->set_flashdata('flash_message', 'Data Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			
			redirect(base_url() . 'index.php?admin/teacher/', 'refresh');
		}
		//	Delete Teacher
		if($param1 == 'delete')
		{
			$where = array('teacher_id' => $param2);
			$this->db->delete('teacher', $where);
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/teacher/', 'refresh');
		}
		
		$page_data['teachers']   = $this->db->get('teacher')->result_array();
		$page_data['page_name']  = 'teacher';
		$page_data['page_title'] = 'Manage Teacher';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE CLASSES ***/
	function classes($param1 = '', $param2 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Class
		if($param1 == 'create')
		{
			$data['name']		=	$this->input->post('name');
			$data['teacher_id']	=	$this->input->post('teacher_id');
			$data['name_numeric'] = ($this->input->post('name_numeric') != null) ? $this->input->post('name_numeric') : null;
			// create new class
			$this->db->insert('class', $data);
			$class_id = $this->db->insert_id();
			// create a section by default
			$data2['class_id']		=	$class_id;
			$data2['name']			=	'A';
			$data2['teacher_id']	=	$data['teacher_id'];
			$this->db->insert('section', $data2);
			
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?admin/classes/', 'refresh');
		}
		//	Update OR Edit Class
		if($param1 == 'do_update')
		{
			$data['name']         = $this->input->post('name');
			$data['teacher_id']   = $this->input->post('teacher_id');
			$data['name_numeric'] = ($this->input->post('name_numeric') != null) ? $this->input->post('name_numeric') : null;
			
			$this->db->update('class', array('class_id' => $param2), $data);
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?admin/classes/', 'refresh');
		}
		//	Delete Class
		if($param1 == 'delete')
		{
			$where = array('class_id' => $param2);
			$this->db->delete('class', $where);
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/classes/', 'refresh');
		}
		
		$page_data['classes']    = $this->db->get('class')->result_array();
		$page_data['page_name']  = 'class';
		$page_data['page_title'] = 'Manage Classes';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE SECTIONS ***/
	function section($class_id = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		// get the first class
		if($class_id == '')
			$class_id	=	$this->db->get('class')->first_row()->class_id;
		
		$page_data['page_name']  = 'section';
		$page_data['page_title'] = 'Manage Sections';
		$page_data['class_id']   = $class_id;
		$this->load->view('portal/index', $page_data);
	}
	
	function sections($param1 = '', $param2 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Section
		if($param1 == 'create')
		{
			$data['name']       =   $this->input->post('name');
			$data['class_id']   =   $this->input->post('class_id');
			$data['teacher_id'] =   $this->input->post('teacher_id');
			if($this->input->post('nick_name') != null)
				$data['nick_name'] = $this->input->post('nick_name');
			
			$validation = duplication_of_section_on_create($data['class_id'], $data['name']);
			if($validation == 1)
			{
				$this->db->insert('section', $data);
				$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			} else
			{
				$this->session->set_flashdata('error_message','Duplicate Name of Section is not Allowed');
			}
			
			redirect(base_url() . 'index.php?admin/section/'.$data['class_id'], 'refresh');
		}
		//	Edit Section
		if($param1 == 'edit')
		{
			$data['name']       =   $this->input->post('name');
			$data['class_id']   =   $this->input->post('class_id');
			$data['teacher_id'] =   $this->input->post('teacher_id');
			$data['nick_name'] = ($this->input->post('nick_name') != null) ? $this->input->post('nick_name') : null;
			
			$validation = duplication_of_section_on_edit($param2, $data['class_id'], $data['name']);
			if($validation == 1)
			{
				$this->db->update('section', array('section_id' => $param2), $data);
				$this->session->set_flashdata('flash_message', 'Data Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'Duplicate Name of Section is not Allowed');
			}
			
			redirect(base_url() . 'index.php?admin/section/'.$data['class_id'], 'refresh');
		}
		//	Delete Section
		if($param1 == 'delete')
		{
			$where = array('section_id' => $param2);
			$this->db->delete('section', $where);
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/section', 'refresh');
		}
	}
	
	function get_class_section($class_id)
	{
		$sections = $this->db->get_where('section', array(
						'class_id' => $class_id
					))->result_array();
		foreach($sections as $row)
		{
			echo '<option value="' . $row['section_id'] . '">' . ucwords($row['name']) . ' (' .ucwords($row['nick_name']) . ')</option>';
		}
	}
	
	function get_class_subject($class_id)
	{
		$subjects = $this->db->get_where('subject', array(
						'class_id' => $class_id
					))->result_array();
		foreach($subjects as $row)
		{
			echo '<option value="' . $row['subject_id'] . '">' . ucwords($row['name']) . '</option>';
		}
	}
	
	function get_class_students($class_id)
	{
		$students = $this->db->get_where('enroll', array(
						'class_id' => $class_id,
						'year' => $this->db->get_where('settings', array('type' => 'running_year'))->row()->description
					))->result_array();
		foreach($students as $row)
		{
			$name = $this->db->get_where('student', array('student_id' => $row['student_id']))->row()->name;
			echo '<option value="' . $row['student_id'] . '">' . ucwords($name) . '</option>';
		}
	}
	
	function get_class_students_mass($class_id)
	{
		$students = $this->db->get_where('enroll', array(
						'class_id' => $class_id,
						'year' => $this->db->get_where('settings', array('type' => 'running_year'))->row()->description
					))->result_array();
		echo '<div class="form-group row">
				<label for="datepicker2" class="col-sm-3 control-label"> &nbsp; Students </label>
				<div class="col-sm-9">
					<div class="card-header">
						<a class="btn btn-primary btn-sm" href="javascript:;" onclick="select()">
							Select All
						</a>
						<a class="btn btn-primary btn-sm" href="javascript:;" onclick="unselect()">
							Select None
						</a>
					</div>
					<div class="card-body">';
		
		foreach($students as $row)
		{
			$name = $this->db->get_where('student', array('student_id' => $row['student_id']))->row()->name;
			echo '		<div class="form-group clearfix">
							<div class="icheck-primary">
								<input type="checkbox" class="check" name="student_id[]" value="'.$row['student_id'].'" id="checkboxPrimary'.$row['student_id'].'">
								<label for="checkboxPrimary'.$row['student_id'].'">'.
									ucwords($name).
								'</label>
							</div>
						</div>';
		}
		
		echo '		</div>
				</div>
			</div>';
	}
	
	/*** MANAGE SUBJECTS ***/
	function subject($class_id = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		// get the first class
		if($class_id == '')
			$class_id	=	$this->db->get('class')->first_row()->class_id;
		
		$page_data['page_name']  = 'subject';
		$page_data['page_title'] = 'Manage Subjects';
		$page_data['class_id']   = $class_id;
		$this->load->view('portal/index', $page_data);
	}
	
	function subjects($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Subject
		if($param1 == 'create')
		{
			$data['name']       = $this->input->post('name');
			$data['class_id']   = $this->input->post('class_id');
			$data['year']       = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			if($this->input->post('teacher_id') != null) {
				$data['teacher_id'] = $this->input->post('teacher_id');
			}
			if($this->input->post('section_id') == 'all') {
				$data['section_id']   = 0;
			} else {
				$data['section_id']   = $this->input->post('section_id');
			}
			
			$this->db->insert('subject', $data);
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?admin/subject/'.$data['class_id'], 'refresh');
		}
		//	Update Subject
		if($param1 == 'do_update')
		{
			$data['name']       = $this->input->post('name');
			$data['class_id']   = $this->input->post('class_id');
			$data['section_id']   = $this->input->post('section_id');
			$data['teacher_id'] = $this->input->post('teacher_id');
			$data['year']       = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			
			$where = array('subject_id' => $param2);
			$this->db->update('subject', $where, $data);
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?admin/subject/'.$data['class_id'], 'refresh');
		}
		else if($param1 == 'edit')
		{
			$page_data['edit_data'] = $this->db->get_where('subject', array(
					'subject_id' => $param2
					))->result_array();
		}
		//	Delete Subject
		if($param1 == 'delete') 
		{
			$where = array('subject_id' => $param2);
			$this->db->delete('subject', $where);
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/subject/'.$param3, 'refresh');
		}
	}
	
	function get_class_section_select($class_id)
	{
		$page_data['class_id'] = $class_id;
		$this->load->view('portal/admin/class_section_selector', $page_data);
	}
	
	function class_section_edit($class_id, $subject_id)
	{
		$page_data['class_id'] = $class_id;
		$page_data['subject_id'] = $subject_id;
		$this->load->view('portal/admin/class_section_edit', $page_data);
	}
	
	//	ACADEMIC SYLLABUS	//
	function academic_syllabus($class_id = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		// detect the first class
		if ($class_id == '')
			$class_id	= $this->db->get('class')->first_row()->class_id;
		
		$page_data['page_name']  = 'academic_syllabus';
		$page_data['page_title'] = 'Academic Syllabus';
		$page_data['class_id']   = $class_id;
		$this->load->view('portal/index', $page_data);
	}
	
	function upload_academic_syllabus()
	{
		$data['academic_syllabus_code']	=  	substr(md5(rand(0, 1000000)), 0, 7);
		if ($this->input->post('description') != null) {
			$data['description'] = $this->input->post('description');
		}
		$data['title']					=	$this->input->post('title');
		$data['class_id']				=	$this->input->post('class_id');
		$data['subject_id']				=	$this->input->post('subject_id');
		$data['uploader_type']			=	$this->session->userdata('login_type');
		$data['uploader_id']			=	$this->session->userdata('login_user_id');
		$data['year']					=	$this->db->get_where('settings',array('type'=>'running_year'))->row()->description;
		$data['timestamp']				=	strtotime(date("Y-m-d H:i:s"));
		//uploading file
		$upload_path   =  'uploads/syllabus/';
		$file_name = $_FILES['file_name']['name'];
		$file_type = '.'.strtolower(pathinfo($upload_path.$file_name, PATHINFO_EXTENSION));
		move_uploaded_file($_FILES['file_name']['tmp_name'], $upload_path.trim($data['title']).$file_type);
		
		$data['file_name'] = trim($data['title']).$file_type;
		
		$this->db->insert('academic_syllabus', $data);
		$this->session->set_flashdata('flash_message', 'Syllabus Uploaded');
		redirect(base_url() . 'index.php?admin/academic_syllabus/'.$data['class_id'], 'refresh');
	}
	
	function download_academic_syllabus($academic_syllabus_code)
	{
		set_time_limit(0);
		
		$file_name = $this->db->get_where('academic_syllabus', array(
			'academic_syllabus_code' => $academic_syllabus_code
		))->row()->file_name;
		
		$file = "uploads/syllabus/".$file_name;
		
		force_download($file, $file_name);
	}
	
	function delete_academic_syllabus($academic_syllabus_code)
	{
		$file_name = $this->db->get_where('academic_syllabus', array(
			'academic_syllabus_code' => $academic_syllabus_code
		))->row()->file_name;
		
		if(file_exists('uploads/syllabus/'.$file_name)) {
			unlink('uploads/syllabus/'.$file_name);
		}
		$where = array('academic_syllabus_code' => $academic_syllabus_code);
		$this->db->delete('academic_syllabus', $where);
		
		$this->session->set_flashdata('flash_message', 'Data Deleted');
		redirect(base_url() . 'index.php?admin/academic_syllabus', 'refresh');
	}
	
	//	STUDY MATERIAL	//
	function study_material($task = "", $document_id = "")
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Study Material
		if ($task == "create")
		{
			save_study_material_info();
			$this->session->set_flashdata('flash_message', 'Study Material Info Saved Successfully');
			redirect(base_url() . 'index.php?admin/study_material', 'refresh');
		}
		//	Update Study Material
		if ($task == "update")
		{
			update_study_material_info($document_id);
			$this->session->set_flashdata('flash_message', 'Study Material Info Updated Successfully');
			redirect(base_url() . 'index.php?admin/study_material', 'refresh');
		}
		//	Delete Study Material
		if ($task == "delete")
		{
			delete_study_material_info($document_id);
			$this->session->set_flashdata('flash_message', 'Study Material Info Deleted');
			redirect(base_url() . 'index.php?admin/study_material', 'refresh');
		}
		
		$data['study_material_info']    = select_study_material_info();
		$data['page_name']              = 'study_material';
		$data['page_title']             = 'Study Materials';
		$this->load->view('portal/index', $data);
	}
	
	function download_study_material($document_id)
	{
		set_time_limit(0);
		
		$file_name = $this->db->get_where('document', array(
			'document_id' => $document_id
		))->row()->file_name;
		
		$file = "uploads/document/".$file_name;
		
		force_download($file, $file_name);
	}
	
	/*** MANAGE CLASS ROUTINE ***/
	function class_routine($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Class Routine
		if($param1 == 'create')
		{
			if($this->input->post('class_id') != null){
				$data['class_id']       = $this->input->post('class_id');
			}
			$data['section_id']     = $this->input->post('section_id');
			$data['subject_id']     = $this->input->post('subject_id');
			//	AM for starting time
			if($this->input->post('time_start_ampm') == 1){
				$data['time_start'] = $this->input->post('time_start');
			}//	PM for starting time
			elseif($this->input->post('time_start_ampm') == 2){
				$data['time_start'] = $this->input->post('time_start') + 12;
			}
			//	AM for ending time
			if($this->input->post('time_end_ampm') == 1){
				$data['time_end'] = $this->input->post('time_end');
			}//	PM for ending time
			elseif($this->input->post('time_end_ampm') == 2){
				$data['time_end'] = $this->input->post('time_end') + 12;
			}
			$data['time_start_min']	= $this->input->post('time_start_min');
			$data['time_end_min']	= $this->input->post('time_end_min');
			$data['day']			= $this->input->post('day');
			$data['year']			= $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			// checking duplication
			$array = array(
				'section_id'		=> $data['section_id'],
				'class_id'			=> $data['class_id'],
				'time_start'		=> $data['time_start'],
				'time_end'			=> $data['time_end'],
				'time_start_min'	=> $data['time_start_min'],
				'time_end_min'		=> $data['time_end_min'],
				'day'				=> $data['day'],
				'year'				=> $data['year']
			);
			$validation = duplication_of_class_routine_on_create($array);
			if($validation == 1)
			{
				$this->db->insert('class_routine', $data);
				$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			} else
			{
				$this->session->set_flashdata('error_message', 'Time Conflicts');
			}
			
			redirect(base_url() . 'index.php?admin/class_routine_view/'.$data['class_id'], 'refresh');
		}
		//	Update Class Routine
		if($param1 == 'do_update')
		{
			$data['class_id']       = $this->input->post('class_id');
			if($this->input->post('section_id') != '') {
				$data['section_id'] = $this->input->post('section_id');
			}
			$data['subject_id']     = $this->input->post('subject_id');
			//	AM for starting time
			if($this->input->post('time_start_ampm') == 1){
				$data['time_start'] = $this->input->post('time_start');
			}//	PM for starting time
			elseif($this->input->post('time_start_ampm') == 2){
				$data['time_start'] = $this->input->post('time_start') + 12;
			}
			//	AM for ending time
			if($this->input->post('time_end_ampm') == 1){
				$data['time_end'] = $this->input->post('time_end');
			}//	PM for ending time
			elseif($this->input->post('time_end_ampm') == 2){
				$data['time_end'] = $this->input->post('time_end') + 12;
			}
			$data['time_start_min'] = $this->input->post('time_start_min');
			$data['time_end_min']   = $this->input->post('time_end_min');
			$data['day']            = $this->input->post('day');
			$data['year']           = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			if($data['subject_id'] != '')
			{
				// checking duplication
				$array = array(
					'section_id'		=> $data['section_id'],
					'class_id'			=> $data['class_id'],
					'time_start'		=> $data['time_start'],
					'time_end'			=> $data['time_end'],
					'time_start_min'	=> $data['time_start_min'],
					'time_end_min'		=> $data['time_end_min'],
					'day'				=> $data['day'],
					'year'				=> $data['year']
				);
				$validation = duplication_of_class_routine_on_edit($array, $param2);
				
				if($validation == 1) {
					$where = array('class_routine_id' => $param2);
					$this->db->update('class_routine', $where, $data);
					$this->session->set_flashdata('flash_message', 'Data Updated');
				} else
				{
					$this->session->set_flashdata('error_message', 'Time Conflicts');
				}
			} else
			{
				$this->session->set_flashdata('error_message', 'Subject is not found');
			}
			
			redirect(base_url() . 'index.php?admin/class_routine_view/'.$data['class_id'], 'refresh');
		}
		else if($param1 == 'edit')
		{
			$page_data['edit_data'] = $this->db->get_where('class_routine', array(
				'class_routine_id' => $param2
			))->result_array();
		}
		//	Delete Class Routine
		if($param1 == 'delete')
		{
			$class_id = $this->db->get_where('class_routine', array('class_routine_id' => $param2))->row()->class_id;
			$where = array('class_routine_id' => $param2);
			$this->db->delete('class_routine', $where);
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/class_routine_view/'.$class_id, 'refresh');
		}
	}
	
	function class_routine_view($class_id = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		// get the first class
		if($class_id == '')
			$class_id	=	$this->db->get('class')->first_row()->class_id;
		
		$page_data['page_name']  = 'class_routine_view';
		$page_data['class_id']  =   $class_id;
		$page_data['page_title'] = 'Manage Class Routine';
		$this->load->view('portal/index', $page_data);
	}
	
	function get_class_section_subject($class_id)
	{
		$page_data['class_id'] = $class_id;
		$this->load->view('portal/admin/class_routine_section_subject_selector', $page_data);
	}
	
	function section_subject_edit($class_id, $class_routine_id)
	{
		$page_data['class_id']          =   $class_id;
		$page_data['class_routine_id']  =   $class_routine_id;
		$this->load->view('portal/admin/class_routine_section_subject_edit', $page_data);
	}
	
	/*** MANAGE ATTENDANCE ***/
	function manage_attendance()
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  =  'manage_attendance';
		$page_data['page_title'] =  'Manage Attendance of Class';
		$this->load->view('portal/index', $page_data);
	}
	
	function manage_attendance_view($class_id = '', $section_id = '', $timestamp = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['class_id'] = $class_id;
		$page_data['section_id'] = $section_id;
		$page_data['timestamp'] = $timestamp;
		$page_data['page_name'] = 'manage_attendance_view';
		$class_name = $this->db->get_where('class', array(
			'class_id' => $class_id
		))->row()->name;
		$section_name = $this->db->get_where('section', array(
			'section_id' => $section_id
		))->row()->name;
		$page_data['page_title'] = 'Manage Attendance of Class'.' '.$class_name.' : Section'.' '.$section_name;
		$this->load->view('portal/index', $page_data);
	}
	
	function attendance_selector()
	{
		$running_year       = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
		$data['class_id']   = $this->input->post('class_id');
		$data['year']       = $running_year;
		$data['timestamp']  = strtotime($this->input->post('timestamp'));
		$data['section_id'] = $this->input->post('section_id');
		
		$query = $this->db->get_where('attendance', array(
			'class_id'		=> $data['class_id'],
			'section_id'	=> $data['section_id'],
			'year'			=> $data['year'],
			'timestamp'		=> $data['timestamp']
		));
		if($query->num_rows() < 1)
		{
			$students = $this->db->get_where('enroll', array(
				'class_id'		=> $data['class_id'],
				'section_id'	=> $data['section_id'],
				'year'			=> $data['year']
			))->result_array();
			
			foreach($students as $row)
			{
				$attn_data['class_id']   = $data['class_id'];
				$attn_data['year']       = $data['year'];
				$attn_data['timestamp']  = $data['timestamp'];
				$attn_data['section_id'] = $data['section_id'];
				$attn_data['student_id'] = $row['student_id'];
				$this->db->insert('attendance', $attn_data);
			}
		}
		
		redirect(base_url().'index.php?admin/manage_attendance_view/'.$data['class_id'].'/'.$data['section_id'].'/'.$data['timestamp'], 'refresh');
	}
	
	function attendance_update($class_id = '', $section_id = '', $timestamp = '')
	{
		$attendance_of_students = $this->db->get_where('attendance', array(
			'class_id'		=> $class_id,
			'section_id'	=> $section_id,
			'year'			=> $this->db->get_where('settings', array('type' => 'running_year'))->row()->description,
			'timestamp'		=> $timestamp
		))->result_array();
		
		foreach($attendance_of_students as $row)
		{
			$attendance_status = $this->input->post('status_'.$row['attendance_id']);
			$where = array('attendance_id' => $row['attendance_id']);
			$this->db->update('attendance', $where, array('status' => $attendance_status));
			/*
			if ($attendance_status == 2)
			{
				if ($active_sms_service != '' || $active_sms_service != 'disabled')
				{
					$student_name   = $this->db->get_where('student', array('student_id' => $row['student_id']))->row()->name;
					$parent_id      = $this->db->get_where('student', array('student_id' => $row['student_id']))->row()->parent_id;
					$message        = 'Your child' . ' ' . $student_name . 'is absent today.';
					if($parent_id != null && $parent_id != 0){
						$receiver_phone = $this->db->get_where('parent', array('parent_id' => $parent_id))->row()->phone;
						if($receiver_phone != '' || $receiver_phone != null){
							$this->sms_model->send_sms($message,$receiver_phone);
						} else{
							$this->session->set_flashdata('error_message', get_phrase('parent_phone_number_is_not_found'));
						}
					} else{
						$this->session->set_flashdata('error_message', get_phrase('parent_phone_number_is_not_found'));
					}
				}
			}
			*/
		}
		$this->session->set_flashdata('flash_message', 'Attendance Updated');
		redirect(base_url().'index.php?admin/manage_attendance_view/'.$class_id.'/'.$section_id.'/'.$timestamp, 'refresh');
	}
	
	//	ATTENDANCE REPORT	//
	function attendance_report()
	{
		$page_data['month']        = date('m');
		$page_data['page_name']    = 'attendance_report';
		$page_data['page_title']   = 'Attendance Report';
		$this->load->view('portal/index', $page_data);
	}
	
	function attendance_report_view($class_id = '', $section_id = '', $month = '', $sessional_year = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$class_name						= $this->db->get_where('class', array('class_id' => $class_id))->row()->name;
		$section_name					= $this->db->get_where('section', array('section_id' => $section_id))->row()->name;
		$page_data['class_id']			= $class_id;
		$page_data['section_id']		= $section_id;
		$page_data['month']				= $month;
		$page_data['sessional_year']	= $sessional_year;
		$page_data['page_name']			= 'attendance_report_view';
		$page_data['page_title']		= 'Attendance Report of Class '.$class_name.' : Section '.$section_name;
		$this->load->view('portal/index', $page_data);
	}
	
	function attendance_report_print_view($class_id ='', $section_id = '', $month = '', $sessional_year = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['class_id']			= $class_id;
		$page_data['section_id']		= $section_id;
		$page_data['month']				= $month;
		$page_data['sessional_year']	= $sessional_year;
		$this->load->view('portal/admin/attendance_report_print_view', $page_data);
	}
	
	function attendance_report_selector()
	{
		if($this->input->post('class_id') == '' || $this->input->post('sessional_year') == '')
		{
			$this->session->set_flashdata('error_message', 'Please Make Sure Class and Sessional Year are Selected');
			redirect(base_url() . 'index.php?admin/attendance_report', 'refresh');
		}
		
		$data['class_id']		= $this->input->post('class_id');
		$data['section_id']		= $this->input->post('section_id');
		$data['month']			= $this->input->post('month');
		$data['sessional_year']	= $this->input->post('sessional_year');
		redirect(base_url() . 'index.php?admin/attendance_report_view/'.$data['class_id'].'/'.$data['section_id'].'/'.$data['month'].'/'.$data['sessional_year'], 'refresh');
	}
	
	/*** MANAGE EXAMS ***/
	function exam($param1 = '', $param2 = '' , $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Exam
		if($param1 == 'create')
		{
			$data['name']    = $this->input->post('name');
			$data['date']    = $this->input->post('date');
			$data['year']    = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			if ($this->input->post('comment') != null) {
				$data['comment'] = $this->input->post('comment');
			}
			$data['status'] = 'unavailable';
			$this->db->insert('exam', $data);
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?admin/exam/', 'refresh');
		}
		//	Update Exam
		if($param1 == 'do_update')
		{
			$data['name']	= $this->input->post('name');
			$data['date']	= $this->input->post('date');
			if($this->input->post('comment') != null) {
				$data['comment'] = $this->input->post('comment');
			} else {
				$data['comment'] = null;
			}
			$data['year']	= $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			$data['status'] = $this->input->post('status');
			
			$where = array('exam_id' => $param2);
			$this->db->update('exam', $where, $data);
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?admin/exam/', 'refresh');
		}
		//	Delete Exam
		if($param1 == 'delete')
		{
			$where = array('exam_id' => $param2);
			$this->db->delete('exam', $where);
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/exam/', 'refresh');
		}
		
		$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
		$page_data['exams']      = $this->db->get_where('exam', array('year' => $running_year))->result_array();
		$page_data['page_name']  = 'exam';
		$page_data['page_title'] = 'Manage Exams';
		$this->load->view('portal/index', $page_data);
	}
	
	//	MANAGE GRADES	//
	function grade($param1 = '', $param2 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Crreate Grade
		if($param1 == 'create')
		{
			$data['name']        = $this->input->post('name');
			$data['grade_point'] = $this->input->post('grade_point');
			$data['mark_from']   = $this->input->post('mark_from');
			$data['mark_upto']   = $this->input->post('mark_upto');
			if ($this->input->post('comment') != null) {
				$data['comment'] = $this->input->post('comment');
			}
			
			$this->db->insert('grade', $data);
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?admin/grade/', 'refresh');
		}
		//	Update Grade
		if($param1 == 'do_update')
		{
			$data['name']        = $this->input->post('name');
			$data['grade_point'] = $this->input->post('grade_point');
			$data['mark_from']   = $this->input->post('mark_from');
			$data['mark_upto']   = $this->input->post('mark_upto');
			if($this->input->post('comment') != null) {
				$data['comment'] = $this->input->post('comment');
			} else {
				$data['comment'] = null;
			}
			
			$where  = array('grade_id' => $param2);
			$this->db->update('grade', $where, $data);
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?admin/grade/', 'refresh');
		}
		//	Delete Grade
		if($param1 == 'delete')
		{
			$where = array('grade_id' => $param2);
			$this->db->delete('grade', $where);
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/grade/', 'refresh');
		}
		
		$page_data['grades']     = $this->db->get('grade')->result_array();
		$page_data['page_name']  = 'grade';
		$page_data['page_title'] = 'Manage Grades';
		$this->load->view('portal/index', $page_data);
	}
	
	//	MANAGE EXAM MARKS	//
	function marks_manage()
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  =   'marks_manage';
		$page_data['page_title'] = 'Manage Exam Marks';
		$this->load->view('portal/index', $page_data);
	}
	
	function marks_manage_view($exam_id = '', $class_id = '', $section_id = '', $subject_id = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['exam_id']    =   $exam_id;
		$page_data['class_id']   =   $class_id;
		$page_data['subject_id'] =   $subject_id;
		$page_data['section_id'] =   $section_id;
		$page_data['page_name']  =   'marks_manage_view';
		$page_data['page_title'] = 'Manage Exam Marks';
		$this->load->view('portal/index', $page_data);
	}
	
	function marks_selector()
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$data['exam_id']    = $this->input->post('exam_id');
		$data['class_id']   = $this->input->post('class_id');
		$data['section_id'] = $this->input->post('section_id');
		$data['subject_id'] = $this->input->post('subject_id');
		$data['year']       = $this->db->get_where('settings', array('type'=>'running_year'))->row()->description;
		if($data['class_id'] != '' && $data['exam_id'] != '')
		{
			$query = $this->db->get_where('mark', array(
				'exam_id' => $data['exam_id'],
				'class_id' => $data['class_id'],
				'section_id' => $data['section_id'],
				'subject_id' => $data['subject_id'],
				'year' => $data['year']
			));
			
			if($query->num_rows() < 1)
			{
				$students = $this->db->get_where('enroll', array(
					'class_id' => $data['class_id'],
					'section_id' => $data['section_id'],
					'year' => $data['year']
				))->result_array();
				
				foreach($students as $row)
				{
					$data['student_id'] = $row['student_id'];
					$this->db->insert('mark', $data);
				}
			}
			
			redirect(base_url() . 'index.php?admin/marks_manage_view/'.$data['exam_id'].'/'.$data['class_id'].'/'.$data['section_id'].'/'.$data['subject_id'], 'refresh');
		} else
		{
			$this->session->set_flashdata('error_message', 'Select All The Fields');
			$page_data['page_name']		= 'marks_manage';
			$page_data['page_title']	= 'Manage Exam Marks';
			$this->load->view('portal/index', $page_data);
		}
	}
	
	function marks_update($exam_id = '', $class_id = '', $section_id = '', $subject_id = '')
	{
		if($class_id != '' && $exam_id != '')
		{
			$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			$marks_of_students = $this->db->get_where('mark', array(
				'exam_id' => $exam_id,
				'class_id' => $class_id,
				'section_id' => $section_id,
				'year' => $running_year,
				'subject_id' => $subject_id
			))->result_array();
			
			foreach($marks_of_students as $row)
			{
				$mark_total = $this->input->post('mark_total_'.$row['mark_id']);
				$obtained_marks = $this->input->post('marks_obtained_'.$row['mark_id']);
				$comment = $this->input->post('comment_'.$row['mark_id']);
				$where = array('mark_id' => $row['mark_id']);
				$this->db->update('mark', $where, array('mark_obtained' => $obtained_marks, 'mark_total' => $mark_total, 'comment' => $comment));
			}
			
			$this->session->set_flashdata('flash_message', 'Marks Updated');
			redirect(base_url().'index.php?admin/marks_manage_view/'.$exam_id.'/'.$class_id.'/'.$section_id.'/'.$subject_id , 'refresh');
		} else
		{
			$this->session->set_flashdata('error_message', 'Select All The Fields');
			$page_data['page_name']		= 'marks_manage';
			$page_data['page_title']	= 'Manage Exam Marks';
			$this->load->view('portal/index', $page_data);
		}
	}
	
	function mark_class_section($class_id)
	{
		$sections = $this->db->get_where('section', array('class_id' => $class_id))->result_array();
		foreach($sections as $row)
		{
			echo '<option value="' . $row['section_id'] . '">' . ucwords($row['name']) .' ('. ucwords($row['nick_name']) . ') </option>';
		}
	}
	
	function mark_class_section_subject($class_id, $section_id)
	{
		$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
		$sql = 'SELECT * FROM `subject` WHERE'.
				' `class_id` = "'.$class_id.
				'" AND `year` = "'.$running_year.
				'" AND (`section_id` = "'.$section_id.'" OR `section_id` = 0)';
		$subjects = $this->db->query($sql)->result_array();
		foreach($subjects as $row)
		{
			echo '<option value="' . $row['subject_id'] . '">' . ucwords($row['name']) . '</option>';
		}
	}
	
	/*** MANAGE OWN PROFILE AND CHANGE PASSWORD ***/
	function manage_profile($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Update Profile
		if($param1 == 'update_profile_info')
		{
			$data['name']  = $this->input->post('name');
			$data['email'] = $this->input->post('email');
			
			$admin_id = $this->session->userdata('admin_id');
			
			$validation = email_validation_for_edit($data['email'], $admin_id, 'admin');
			if($validation == 1)
			{
				$where = array('admin_id' => $this->session->userdata('admin_id'));
				$this->db->update('admin', $where, $data);
				move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/admin_image/'.$this->session->userdata('admin_id').'.jpg');
				$this->session->set_flashdata('flash_message', 'Account Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			redirect(base_url() . 'index.php?admin/manage_profile/', 'refresh');
		}
		//	Change Password
		if($param1 == 'change_password')
		{
			$data['password']		= $this->input->post('password');
			$data['new_password']	= $this->input->post('new_password');
			$data['cnew_password']	= $this->input->post('cnew_password');
			
			$current_password = $this->db->get_where('admin', array(
				'admin_id' => $this->session->userdata('admin_id')
			))->row()->password;
			if($current_password == $data['password'] && $data['new_password'] == $data['cnew_password'])
			{
				$where = array('admin_id' => $this->session->userdata('admin_id'));
				$this->db->update('admin', $where, array(
					'password' => $data['new_password']
				));
				$this->session->set_flashdata('flash_message', 'Password Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'Password Mismatch');
			}
			redirect(base_url() . 'index.php?admin/manage_profile/', 'refresh');
		}
		
		$page_data['page_name']  = 'manage_profile';
		$page_data['page_title'] = 'Manage Profile';
		$page_data['edit_data']  = $this->db->get_where('admin', array(
			'admin_id' => $this->session->userdata('admin_id')
		))->result_array();
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE ACCOUNTANTS ***/
	function accountant($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Accountant
		if($param1 == 'create')
		{
			$data['name']       = $this->input->post('name');
			$data['email']      = $this->input->post('email');
			$data['password']   = $this->input->post('password');
			
			$validation = email_validation($data['email']);
			if($validation == 1)
			{
				$this->db->insert('accountant', $data);
				$this->session->set_flashdata('flash_message', 'Data Added Successfully');
				//$this->email_model->account_opening_email('accountant', $data['email'], $this->input->post('password')); //SEND EMAIL ACCOUNT OPENING EMAIL
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			
			redirect(base_url() . 'index.php?admin/accountant', 'refresh');
		}
		//	Edit Accountant
		if($param1 == 'edit')
		{
			$data['name']   = $this->input->post('name');
			$data['email']  = $this->input->post('email');
			
			$validation = email_validation_for_edit($data['email'], $param2, 'accountant');
			if($validation == 1){
				$where = array('accountant_id' => $param2);
				$this->db->update('accountant', $where, $data);
				$this->session->set_flashdata('flash_message', 'Data Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			
			redirect(base_url() . 'index.php?admin/accountant', 'refresh');
		}
		//	Delete Accountant
		if($param1 == 'delete')
		{
			$where = array('accountant_id' => $param2);
			$this->db->delete('accountant', $where);
			
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/accountant', 'refresh');
		}
		
		$page_data['page_title']    = 'Manage Accountants';
		$page_data['page_name']     = 'accountant';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE LIBRARY BOOKS ***/
	function book($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Library
		if($param1 == 'create')
		{
			$data['name']        = $this->input->post('name');
			$data['class_id']    = $this->input->post('class_id');
			if ($this->input->post('description') != null) {
				$data['description'] = $this->input->post('description');
			}
			if ($this->input->post('copies') != null) {
				$data['total_copies'] = $this->input->post('copies');
			}
			if ($this->input->post('author') != null) {
				$data['author'] = $this->input->post('author');
			}
			if(!empty($_FILES["file_name"]["name"])) {
			$data['file_name'] = $_FILES["file_name"]["name"];
			}
			$this->db->insert('book', $data);
			
			if(!empty($_FILES["file_name"]["name"])) {
				move_uploaded_file($_FILES["file_name"]["tmp_name"], "uploads/library/".$_FILES["file_name"]["name"]);
			}
			
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?admin/book', 'refresh');
		}
		//	Update Library
		if($param1 == 'do_update')
		{
			$data['name']        = $this->input->post('name');
			$data['class_id']    = $this->input->post('class_id');
			if($this->input->post('description') != null) {
				$data['description'] = $this->input->post('description');
			} else {
				$data['description'] = null;
			}
			if($this->input->post('copies') != null) {
				$data['total_copies'] = $this->input->post('copies');
			} else {
				$data['total_copies'] = null;
			}
			if($this->input->post('author') != null) {
				$data['author'] = $this->input->post('author');
			} else {
				$data['author'] = null;
			}
			
			if(!empty($_FILES["file_name"]["name"])) {
				$data['file_name'] = $_FILES["file_name"]["name"];
			}
			
			$where = array('book_id' => $param2);
			$this->db->update('book', $where, $data);
			
			if(!empty($_FILES["file_name"]["name"])) {
				move_uploaded_file($_FILES["file_name"]["tmp_name"], "uploads/library/" . $_FILES["file_name"]["name"]);
			}
			
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?admin/book', 'refresh');
		}
		//	Delete Library
		if($param1 == 'delete')
		{
			$where = array('book_id' => $param2);
			$this->db->delete('book', $where);
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/book', 'refresh');
		}
		
		$page_data['books']      = $this->db->get('book')->result_array();
		$page_data['page_name']  = 'book';
		$page_data['page_title'] = 'Manage Library Books';
		$this->load->view('portal/index', $page_data);
	}
	
	function download_book($book_id)
	{
		set_time_limit(0);
		
		$file_name = $this->db->get_where('book', array(
			'book_id' => $book_id
		))->row()->file_name;
		
		$file = "uploads/library/".$file_name;
		
		force_download($file, $file_name);
	}
	
	/*** MANAGE PAYMENT AND INVOICES ***/
	function student_payment($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'student_payment';
		$page_data['page_title'] = 'Manage Students Payment / Invoice';
		$this->load->view('portal/index', $page_data);
	}
	
	function invoice($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Invoice
		if($param1 == 'create')
		{
			$data['student_id']			= $this->input->post('student_id');
			$data['title']				= $this->input->post('title');
			if($this->input->post('description') != null) {
				$data['description']	= $this->input->post('description');
			}
			$data['amount']				= $this->input->post('amount');
			$data['amount_paid']		= $this->input->post('amount_paid');
			$data['due']				= $data['amount'] - $data['amount_paid'];
			if($data['due'] == 0) {
				$data['status']			= 'paid';
			} else if($data['due'] > 0) {
				$data['status']			= 'unpaid';
			}
			$data['creation_timestamp']	= strtotime($this->input->post('date'));
			$data['year']				= $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			
			$this->db->insert('invoice', $data);
			$invoice_id = $this->db->insert_id();
			
			$data2['invoice_id']		=   $invoice_id;
			$data2['student_id']		=   $this->input->post('student_id');
			$data2['title']				=   $this->input->post('title');
			$data2['method']			=   $this->input->post('method');
			$data2['amount']			=   $this->input->post('amount_paid');
			$data2['timestamp']			=   strtotime($this->input->post('date'));
			$data2['year']				=  $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			if($this->input->post('description') != null) {
				$data2['description']	= $this->input->post('description');
			}
			
			$this->db->insert('payment', $data2);
			
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?admin/student_payment', 'refresh');
		}
		//	Create Mass Invoice
		if($param1 == 'create_mass_invoice')
		{
			foreach($this->input->post('student_id') as $id)
			{
				$data['student_id']			= $id;
				$data['title']				= $this->input->post('title');
				$data['description']		= $this->input->post('description');
				$data['amount']				= $this->input->post('amount');
				$data['amount_paid']		= $this->input->post('amount_paid');
				$data['due']				= $data['amount'] - $data['amount_paid'];
				if($data['due'] == 0) {
					$data['status']			= 'paid';
				} else if($data['due'] > 0) {
					$data['status']			= 'unpaid';
				}
				$data['creation_timestamp']	= strtotime($this->input->post('date'));
				$data['year']				= $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
				
				$this->db->insert('invoice', $data);
				$invoice_id = $this->db->insert_id();
				
				$data2['invoice_id']		=   $invoice_id;
				$data2['student_id']		=   $id;
				$data2['title']				=   $this->input->post('title');
				$data2['description']		=   $this->input->post('description');
				$data2['method']			=   $this->input->post('method');
				$data2['amount']			=   $this->input->post('amount_paid');
				$data2['timestamp']			=   strtotime($this->input->post('date'));
				$data2['year']				=   $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
				
				$this->db->insert('payment', $data2);
			}
			
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?admin/student_payment', 'refresh');
		}
		//	Update Invoice
		if($param1 == 'do_update')
		{
			$data['student_id']		= $this->input->post('student_id');
			$data['title']			= $this->input->post('title');
			$data['description']	= $this->input->post('description');
			$data['amount']			= $this->input->post('amount');
			$data['amount_paid']	= $this->input->post('amount_paid');
			$data['due']			= $data['amount'] - $data['amount_paid'];
			if($data['due'] == 0) {
				$data['status']		= 'paid';
			} else if($data['due'] > 0) {
				$data['status']		= 'unpaid';
			}
			$data['creation_timestamp'] = strtotime($this->input->post('date'));
			
			$where = array('invoice_id' => $param2);
			$this->db->update('invoice', $where, $data);
			
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?admin/income', 'refresh');
		}
		else if($param1 == 'edit')
		{
			$page_data['edit_data'] = $this->db->get_where('invoice', array(
				'invoice_id' => $param2
			))->result_array();
		}
		//	Take Payment
		if($param1 == 'take_payment')
		{
			$data['invoice_id']		=   $this->input->post('invoice_id');
			$data['student_id']		=   $this->input->post('student_id');
			$data['title']			=   $this->input->post('title');
			$data['description']	=   $this->input->post('description');
			$data['method']			=   $this->input->post('method');
			$data['amount']			=   $this->input->post('payment');
			$data['timestamp']		=   strtotime($this->input->post('date'));
			$data['year']			=   $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			
			$this->db->insert('payment', $data);
			
			$amount					=   $this->input->post('amount');
			$data2['amount_paid']	=   $this->input->post('amount_paid') + $data['amount'];
			$data2['due']			=   $amount - $data2['amount_paid'];
			if($data2['due'] == 0) {
				$data2['status']	=   'paid';
			} else if ($data2['due'] > 0) {
				$data2['status']	=   'unpaid';
			}
			
			$where = array('invoice_id' => $param2);
			$this->db->update('invoice', $where, $data2);
			
			$this->session->set_flashdata('flash_message', 'Payment Successful');
			redirect(base_url() . 'index.php?admin/income/', 'refresh');
		}
		
		if($param1 == 'delete')
		{
			$where =  array('invoice_id' => $param2);
			$this->db->delete('invoice', $where);
			
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/income', 'refresh');
		}
	}
	
	//	ACCOUNTING	//
	function income($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']		= 'income';
		$page_data['page_title']	= 'Manage Students Payment / Invoice';
		$this->load->view('portal/index', $page_data);
	}
	
	function get_student_specific_payments($student_id = '')
	{
		$account_type				= $this->session->userdata('login_type');
		$page_name					= 'student_specific_payments';
		$page_data['student_id']	= $student_id;
		$this->load->view('portal/'.$account_type.'/'.$page_name.'.php', $page_data);
	}
	
	function expense($param1 = '', $param2 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Expense
		if($param1 == 'create')
		{
			$data['title']					=   $this->input->post('title');
			$data['expense_category_id']	=   $this->input->post('expense_category_id');
			$data['method']					=   $this->input->post('method');
			$data['amount']					=   $this->input->post('amount');
			$data['timestamp']				=   strtotime($this->input->post('timestamp'));
			$data['year']					=   $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			if ($this->input->post('description') != null) {
				$data['description']		=   $this->input->post('description');
			}
			
			$this->db->insert('expense', $data);
			
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?admin/expense', 'refresh');
		}
		//	Edit Expense
		if($param1 == 'edit')
		{
			$data['title']					=   $this->input->post('title');
			$data['expense_category_id']	=   $this->input->post('expense_category_id');
			$data['method']					=   $this->input->post('method');
			$data['amount']					=   $this->input->post('amount');
			$data['timestamp']				=   strtotime($this->input->post('timestamp'));
			$data['year']					=   $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			if($this->input->post('description') != null) {
				$data['description']		=   $this->input->post('description');
			} else {
				$data['description']		=   null;
			}
			
			$where = array('expense_id' => $param2);
			$this->db->update('expense', $where, $data);
			
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?admin/expense', 'refresh');
		}
		//	Delete Expense
		if($param1 == 'delete')
		{
			$where = array('expense_id' => $param2);
			$this->db->delete('expense', $where);
			
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/expense', 'refresh');
		}
		
		$page_data['page_name']  = 'expense';
		$page_data['page_title'] = 'Manage Expenses';
		$this->load->view('portal/index', $page_data);
	}
	
	function expense_category($param1 = '', $param2 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Expense Category
		if($param1 == 'create')
		{
			$data['name']   =   $this->input->post('name');
			$this->db->insert('expense_category', $data);
			
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?admin/expense_category');
		}
		//	Edit Expense Category
		if($param1 == 'edit')
		{
			$data['name']   =   $this->input->post('name');
			$where = array('expense_category_id' => $param2);
			$this->db->update('expense_category', $where, $data);
			
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?admin/expense_category');
		}
		//	Delete Expense Category
		if($param1 == 'delete')
		{
			$where = array('expense_category_id' => $param2);
			$this->db->delete('expense_category', $where);
			
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?admin/expense_category');
		}
		
		$page_data['page_name']		= 'expense_category';
		$page_data['page_title']	= 'Manage Expense Category';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** SITE/SYSTEM SETTINGS ***/
	function system_settings($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('admin_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		if($param1 == 'do_update')
		{
			$data['description'] = $this->input->post('system_name');
			$where = array('type' => 'system_name');
			$this->db->update('settings', $where, $data);
			
			$data2['description'] = $this->input->post('system_title');
			$where = array('type' => 'system_title');
			$this->db->update('settings', $where, $data2);
			
			$data3['description'] = $this->input->post('address');
			$where = array('type' => 'address');
			$this->db->update('settings', $where, $data3);
			
			$data4['description'] = $this->input->post('phone');
			$where = array('type' => 'phone');
			$this->db->update('settings', $where, $data4);
			
			$data['description'] = $this->input->post('system_email');
			$where = array('type' => 'system_email');
			$this->db->update('settings', $where, $data);
			
			$this->session->set_flashdata('flash_message', 'Settings Updated');
			redirect(base_url() . 'index.php?admin/system_settings/', 'refresh');
		}
		
		if($param1 == 'change_session')
		{
			$data['description'] = $this->input->post('running_year');
			$where = array('type' => 'running_year');
			$this->db->update('settings', $where, $data);
			
			$this->session->set_flashdata('flash_message', 'Session Changed');
			redirect(base_url() . 'index.php?admin/system_settings/', 'refresh');
		}
		
		if($param1 == 'upload_logo')
		{
			move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/logo.png');
			$this->session->set_flashdata('flash_message', 'Logo Uploaded');
			redirect(base_url() . 'index.php?admin/system_settings/', 'refresh');
		}
		
		if($param1 == 'change_skin')
		{
			$data['description'] = $param2;
			$where = array('type' => 'skin_colour');
			$this->db->update('settings', $where, $data);
			$this->session->set_flashdata('flash_message', get_phrase('theme_selected'));
			redirect(base_url() . 'index.php?admin/system_settings/', 'refresh');
		}
		
		$page_data['page_name']  = 'system_settings';
		$page_data['page_title'] = 'System Settings';
		$page_data['settings']   = $this->db->get('settings')->result_array();
		$this->load->view('portal/index', $page_data);
	}
}