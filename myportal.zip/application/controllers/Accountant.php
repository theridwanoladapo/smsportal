<?php

class Accountant extends Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->library('session');
		
		//	Cache control
		header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
		header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		header('Pragma: no-cache');
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	}
	
	//	Default function, redirects to Login page if no Accountant logged in yet
	public function index()
	{
		if($this->session->userdata('accountant_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		if($this->session->userdata('accountant_login') == 1)
			redirect(base_url() . 'index.php?accountant/dashboard', 'refresh');
	}
	
	/*** ACCOUNTANT DASHBOARD ***/
	function dashboard()
	{
		if($this->session->userdata('accountant_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'dashboard';
		$page_data['page_title'] = 'Accountant Dashboard';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE PAYMENT AND INVOICES ***/
	function student_payment($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('accountant_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'student_payment';
		$page_data['page_title'] = 'Manage Students Payment / Invoice';
		$this->load->view('portal/index', $page_data);
	}
	
	function invoice($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('accountant_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Invoice
		if($param1 == 'create')
		{
			$data['student_id']			= $this->input->post('student_id');
			$data['title']				= $this->input->post('title');
			if($this->input->post('description') != null) {
				$data['description']	= $this->input->post('description');
			}
			$data['amount']				= $this->input->post('amount');
			$data['amount_paid']		= $this->input->post('amount_paid');
			$data['due']				= $data['amount'] - $data['amount_paid'];
			if($data['due'] == 0) {
				$data['status']			= 'paid';
			} else if($data['due'] > 0) {
				$data['status']			= 'unpaid';
			}
			$data['creation_timestamp']	= strtotime($this->input->post('date'));
			$data['year']				= $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			
			$this->db->insert('invoice', $data);
			$invoice_id = $this->db->insert_id();
			
			$data2['invoice_id']		=   $invoice_id;
			$data2['student_id']		=   $this->input->post('student_id');
			$data2['title']				=   $this->input->post('title');
			$data2['method']			=   $this->input->post('method');
			$data2['amount']			=   $this->input->post('amount_paid');
			$data2['timestamp']			=   strtotime($this->input->post('date'));
			$data2['year']				=  $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			if($this->input->post('description') != null) {
				$data2['description']	= $this->input->post('description');
			}
			
			$this->db->insert('payment', $data2);
			
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?accountant/student_payment', 'refresh');
		}
		//	Create Mass Invoice
		if($param1 == 'create_mass_invoice')
		{
			foreach($this->input->post('student_id') as $id)
			{
				$data['student_id']			= $id;
				$data['title']				= $this->input->post('title');
				$data['description']		= $this->input->post('description');
				$data['amount']				= $this->input->post('amount');
				$data['amount_paid']		= $this->input->post('amount_paid');
				$data['due']				= $data['amount'] - $data['amount_paid'];
				if($data['due'] == 0) {
					$data['status']			= 'paid';
				} else if($data['due'] > 0) {
					$data['status']			= 'unpaid';
				}
				$data['creation_timestamp']	= strtotime($this->input->post('date'));
				$data['year']				= $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
				
				$this->db->insert('invoice', $data);
				$invoice_id = $this->db->insert_id();
				
				$data2['invoice_id']		=   $invoice_id;
				$data2['student_id']		=   $id;
				$data2['title']				=   $this->input->post('title');
				$data2['description']		=   $this->input->post('description');
				$data2['method']			=   $this->input->post('method');
				$data2['amount']			=   $this->input->post('amount_paid');
				$data2['timestamp']			=   strtotime($this->input->post('date'));
				$data2['year']				=   $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
				
				$this->db->insert('payment', $data2);
			}
			
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?accountant/student_payment', 'refresh');
		}
		//	Update Invoice
		if($param1 == 'do_update')
		{
			$data['student_id']		= $this->input->post('student_id');
			$data['title']			= $this->input->post('title');
			$data['description']	= $this->input->post('description');
			$data['amount']			= $this->input->post('amount');
			$data['amount_paid']	= $this->input->post('amount_paid');
			$data['due']			= $data['amount'] - $data['amount_paid'];
			if($data['due'] == 0) {
				$data['status']		= 'paid';
			} else if($data['due'] > 0) {
				$data['status']		= 'unpaid';
			}
			$data['creation_timestamp'] = strtotime($this->input->post('date'));
			
			$where = array('invoice_id' => $param2);
			$this->db->update('invoice', $where, $data);
			
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?accountant/income', 'refresh');
		}
		else if($param1 == 'edit')
		{
			$page_data['edit_data'] = $this->db->get_where('invoice', array(
				'invoice_id' => $param2
			))->result_array();
		}
		//	Take Payment
		if($param1 == 'take_payment')
		{
			$data['invoice_id']		=   $this->input->post('invoice_id');
			$data['student_id']		=   $this->input->post('student_id');
			$data['title']			=   $this->input->post('title');
			$data['description']	=   $this->input->post('description');
			$data['method']			=   $this->input->post('method');
			$data['amount']			=   $this->input->post('payment');
			$data['timestamp']		=   strtotime($this->input->post('date'));
			$data['year']			=   $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			
			$this->db->insert('payment', $data);
			
			$amount					=   $this->input->post('amount');
			$data2['amount_paid']	=   $this->input->post('amount_paid') + $data['amount'];
			$data2['due']			=   $amount - $data2['amount_paid'];
			if($data2['due'] == 0) {
				$data2['status']	=   'paid';
			} else if ($data2['due'] > 0) {
				$data2['status']	=   'unpaid';
			}
			
			$where = array('invoice_id' => $param2);
			$this->db->update('invoice', $where, $data2);
			
			$this->session->set_flashdata('flash_message', 'Payment Successful');
			redirect(base_url() . 'index.php?accountant/income/', 'refresh');
		}
		
		if($param1 == 'delete')
		{
			$where =  array('invoice_id' => $param2);
			$this->db->delete('invoice', $where);
			
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?accountant/income', 'refresh');
		}
	}
	
	//	ACCOUNTING	//
	function income($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('accountant_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']		= 'income';
		$page_data['page_title']	= 'Manage Students Payment / Invoice';
		$this->load->view('portal/index', $page_data);
	}
	
	function get_student_specific_payments($student_id = '')
	{
		$account_type				= $this->session->userdata('login_type');
		$page_name					= 'student_specific_payments';
		$page_data['student_id']	= $student_id;
		$this->load->view('portal/'.$account_type.'/'.$page_name.'.php', $page_data);
	}
	
	function expense($param1 = '', $param2 = '')
	{
		if($this->session->userdata('accountant_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Expense
		if($param1 == 'create')
		{
			$data['title']					=   $this->input->post('title');
			$data['expense_category_id']	=   $this->input->post('expense_category_id');
			$data['method']					=   $this->input->post('method');
			$data['amount']					=   $this->input->post('amount');
			$data['timestamp']				=   strtotime($this->input->post('timestamp'));
			$data['year']					=   $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			if ($this->input->post('description') != null) {
				$data['description']		=   $this->input->post('description');
			}
			
			$this->db->insert('expense', $data);
			
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?accountant/expense', 'refresh');
		}
		//	Edit Expense
		if($param1 == 'edit')
		{
			$data['title']					=   $this->input->post('title');
			$data['expense_category_id']	=   $this->input->post('expense_category_id');
			$data['method']					=   $this->input->post('method');
			$data['amount']					=   $this->input->post('amount');
			$data['timestamp']				=   strtotime($this->input->post('timestamp'));
			$data['year']					=   $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			if($this->input->post('description') != null) {
				$data['description']		=   $this->input->post('description');
			} else {
				$data['description']		=   null;
			}
			
			$where = array('expense_id' => $param2);
			$this->db->update('expense', $where, $data);
			
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?accountant/expense', 'refresh');
		}
		//	Delete Expense
		if($param1 == 'delete')
		{
			$where = array('expense_id' => $param2);
			$this->db->delete('expense', $where);
			
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?accountant/expense', 'refresh');
		}
		
		$page_data['page_name']  = 'expense';
		$page_data['page_title'] = 'Expenses';
		$this->load->view('portal/index', $page_data);
	}
	
	function expense_category($param1 = '', $param2 = '')
	{
		if($this->session->userdata('accountant_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Expense Category
		if($param1 == 'create')
		{
			$data['name']   =   $this->input->post('name');
			$this->db->insert('expense_category', $data);
			
			$this->session->set_flashdata('flash_message', 'Data Added Successfully');
			redirect(base_url() . 'index.php?accountant/expense_category');
		}
		//	Edit Expense Category
		if($param1 == 'edit')
		{
			$data['name']   =   $this->input->post('name');
			$where = array('expense_category_id' => $param2);
			$this->db->update('expense_category', $where, $data);
			
			$this->session->set_flashdata('flash_message', 'Data Updated');
			redirect(base_url() . 'index.php?accountant/expense_category');
		}
		//	Delete Expense Category
		if($param1 == 'delete')
		{
			$where = array('expense_category_id' => $param2);
			$this->db->delete('expense_category', $where);
			
			$this->session->set_flashdata('flash_message', 'Data Deleted');
			redirect(base_url() . 'index.php?accountant/expense_category');
		}
		
		$page_data['page_name']		= 'expense_category';
		$page_data['page_title']	= 'Expense Category';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE OWN PROFILE AND CHANGE PASSWORD ***/
	function manage_profile($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('accountant_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Update Profile
		if($param1 == 'update_profile_info')
		{
			$data['name']  = $this->input->post('name');
			$data['email'] = $this->input->post('email');
			
			$accountant_id = $this->session->userdata('accountant_id');
			
			$validation = email_validation_for_edit($data['email'], $accountant_id, 'accountant');
			if($validation == 1)
			{
				$where = array('accountant_id' => $this->session->userdata('accountant_id'));
				$this->db->update('accountant', $where, $data);
				$this->session->set_flashdata('flash_message', 'Account Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			redirect(base_url() . 'index.php?accountant/manage_profile/', 'refresh');
		}
		//	Change Password
		if($param1 == 'change_password')
		{
			$data['password']		= $this->input->post('password');
			$data['new_password']	= $this->input->post('new_password');
			$data['cnew_password']	= $this->input->post('cnew_password');
			
			$current_password = $this->db->get_where('accountant', array(
				'accountant_id' => $this->session->userdata('accountant_id')
			))->row()->password;
			if($current_password == $data['password'] && $data['new_password'] == $data['cnew_password'])
			{
				$where = array('accountant_id' => $this->session->userdata('accountant_id'));
				$this->db->update('accountant', $where, array(
					'password' => $data['new_password']
				));
				$this->session->set_flashdata('flash_message', 'Password Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'Password Mismatch');
			}
			redirect(base_url() . 'index.php?accountant/manage_profile/', 'refresh');
		}
		
		$page_data['page_name']  = 'manage_profile';
		$page_data['page_title'] = 'Manage Profile';
		$page_data['edit_data']  = $this->db->get_where('accountant', array(
			'accountant_id' => $this->session->userdata('accountant_id')
		))->result_array();
		$this->load->view('portal/index', $page_data);
	}
	

}