<?php

class Student extends Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->library('session');
		
		//	Cache control
		header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
		header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		header('Pragma: no-cache');
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	}
	
	//	Default function, redirects to Login page if no Student logged in yet
	public function index()
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		if($this->session->userdata('student_login') == 1)
			redirect(base_url() . 'index.php?student/dashboard', 'refresh');
	}
	
	/*** PARENT DASHBOARD ***/
	function dashboard()
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'dashboard';
		$page_data['page_title'] = 'Student Dashboard';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** TEACHERS ***/
	function teachers($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'teachers';
		$page_data['page_title'] = 'Teachers';
		$page_data['teachers']   = $this->db->get('teacher')->result_array();
		$this->load->view('portal/index', $page_data);
	}
	
	/*** SUBJECTS ***/
	function subject($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'subject';
		$page_data['page_title'] = 'Subjects';
		$page_data['student_id'] = $this->session->userdata('student_id');
		$this->load->view('portal/index', $page_data);
	}
	
	/*** ACADEMIC SYLLABUS ***/
	function academic_syllabus()
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'academic_syllabus';
		$page_data['page_title'] = 'Academic Syllabus';
		$page_data['student_id'] = $this->session->userdata('student_id');
		$this->load->view('portal/index', $page_data);
	}
	
	function download_academic_syllabus($academic_syllabus_code)
	{
		set_time_limit(0);
		
		$file_name = $this->db->get_where('academic_syllabus', array(
			'academic_syllabus_code' => $academic_syllabus_code
		))->row()->file_name;
		
		$file = "uploads/syllabus/".$file_name;
		
		force_download($file, $file_name);
	}
	
	/*** STUDY MATERIAL ***/
	function study_material()
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$student_id		= $this->session->userdata('student_id');
		$class_id		= $this->db->get_where('enroll', array('student_id' => $student_id))->row()->class_id;
		$order_by		= array("timestamp", "DESC");
		$data['study_material_info']    = $this->db->get_where('document', array('class_id' => $class_id), $order_by)->result_array();;
		$data['page_name']              = 'study_material';
		$data['page_title']             = 'Study Material';
		$data['student_id']				= $student_id;
		$this->load->view('portal/index', $data);
	}
	
	function download_study_material($document_id)
	{
		set_time_limit(0);
		
		$file_name = $this->db->get_where('document', array(
			'document_id' => $document_id
		))->row()->file_name;
		
		$file = "uploads/document/".$file_name;
		
		force_download($file, $file_name);
	}
	
	/*** CLASS ROUTINE ***/
	function class_routine()
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'class_routine';
		$page_data['page_title'] = 'Class Routine';
		$page_data['student_id'] = $this->session->userdata('student_id');
		$this->load->view('portal/index', $page_data);
	}
	
	/*** EXAM RESULTS ***/
	function results()
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'results';
		$page_data['page_title'] = 'Exam Results';
		$page_data['student_id'] = $this->session->userdata('student_id');
		$this->load->view('portal/index', $page_data);
	}
	
	function get_year_exam($year)
	{
		$exams = $this->db->get_where('exam', array('year' => $year, 'status' => 'available'), array('exam_id', 'DESC'))->result_array();
		
		echo '<option value=""> Select </option>';
		
		foreach($exams as $row)
		{
			echo '<option value="' . $row['exam_id'] . '">' . ucwords($row['name']) .' ('. $row['date'] . ') </option>';
		}
	}
	
	function get_student_exam_marks($exam_id, $student_id)
	{
		$account_type				= $this->session->userdata('login_type');
		$page_data['student_id']	= $student_id;
		$page_data['exam_id']		= $exam_id;
		$page_data['year']			= $this->db->get_where('exam', array('exam_id' => $exam_id))->row()->year;
		$page_name					= 'student_marksheet';
		$this->load->view('portal/'.$account_type.'/'.$page_name.'.php', $page_data);
	}
	
	/*** LIBRARY/BOOKS ***/
	function book($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'book';
		$page_data['page_title'] = 'Library Books';
		$page_data['books']      = $this->db->get('book')->result_array();
		$this->load->view('portal/index', $page_data);
	}
	
	//	BOOK REQUESTS
	function book_request($param1 = '', $param2 = '')
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		if ($param1 == 'create')
		{
			create_book_request();
			$this->session->set_flashdata('flash_message', 'Book Request Successful');
			redirect(base_url() . 'index.php?student/book_request', 'refresh');
		}
		
		$data['page_name']	= 'book_request';
		$data['page_title']	= 'Book Requests';
		$this->load->view('portal/index', $data);
	}
	
	function get_class_books($class_id)
	{
		$books = $this->db->get_where('book', array('class_id' => $class_id))->result_array();
		
		echo '<option value=""> Select </option>';
		
		foreach($books as $row)
		{
			echo '<option value="' . $row['book_id'] . '">' . ucwords($row['name']) . '</option>';
		}
	}
	
	/*** INVOICES / PAYMENT WITH STATUS ***/
	function invoice()
	{
		$student_profile = $this->db->get_where('student', array(
			'student_id' => $this->session->userdata('student_id')
		))->row();
		
		$page_data['student_id'] = $student_profile->student_id;
		$page_data['page_name']  = 'invoice';
		$page_data['page_title'] = 'Students Invoice / Payment';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE OWN PROFILE AND CHANGE PASSWORD ***/
	function manage_profile($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('student_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Change Password
		if($param1 == 'change_password')
		{
			$data['password']		= $this->input->post('password');
			$data['new_password']	= $this->input->post('new_password');
			$data['cnew_password']	= $this->input->post('cnew_password');
			
			$current_password = $this->db->get_where('student', array(
				'student_id' => $this->session->userdata('student_id')
			))->row()->password;
			if($current_password == $data['password'] && $data['new_password'] == $data['cnew_password'])
			{
				$where = array('student_id' => $this->session->userdata('student_id'));
				$this->db->update('student', $where, array(
					'password' => $data['new_password']
				));
				$this->session->set_flashdata('flash_message', 'Password Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'Password Mismatch');
			}
			redirect(base_url() . 'index.php?student/manage_profile/', 'refresh');
		}
		
		$page_data['page_name']  = 'manage_profile';
		$page_data['page_title'] = 'Manage Profile';
		$page_data['edit_data']  = $this->db->get_where('student', array(
			'student_id' => $this->session->userdata('student_id')
		))->result_array();
		$this->load->view('portal/index', $page_data);
	}
	

}