<?php

class Teacher extends Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->library('session');
		
		//	Cache control
		header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
		header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		header('Pragma: no-cache');
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	}
	
	//	Default function, redirects to Login page if no Teacher logged in yet
	public function index()
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		if($this->session->userdata('teacher_login') == 1)
			redirect(base_url() . 'index.php?teacher/dashboard', 'refresh');
	}
	
	/*** TEACHER DASHBOARD ***/
	function dashboard()
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'dashboard';
		$page_data['page_title'] = 'Teacher Dashboard';
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE STUDENTS ***/
	function student_information($class_id = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  	= 'student_information';
		$page_data['page_title'] 	= 'Student Information';
		$page_data['class_id'] 	= $class_id;
		$this->load->view('portal/index', $page_data);
	}
	
	function student_profile($student_id)
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'student_profile';
		$page_data['page_title'] = 'Student Profile';
		$page_data['student_id']  = $student_id;
		$this->load->view('portal/index', $page_data);
	}
	
	function get_class_section($class_id)
	{
		$sections = $this->db->get_where('section', array(
						'class_id' => $class_id
					))->result_array();
		foreach($sections as $row)
		{
			echo '<option value="' . $row['section_id'] . '">' . ucwords($row['name']) . ' (' .ucwords($row['nick_name']) . ')</option>';
		}
	}
	
	function get_class_subject($class_id)
	{
		$subjects = $this->db->get_where('subject', array(
						'class_id' => $class_id
					))->result_array();
		foreach($subjects as $row)
		{
			echo '<option value="' . $row['subject_id'] . '">' . ucwords($row['name']) . '</option>';
		}
	}
	
	function get_class_students($class_id)
	{
		$students = $this->db->get_where('enroll', array(
						'class_id' => $class_id,
						'year' => $this->db->get_where('settings', array('type' => 'running_year'))->row()->description
					))->result_array();
		foreach($students as $row)
		{
			$name = $this->db->get_where('student', array('student_id' => $row['student_id']))->row()->name;
			echo '<option value="' . $row['student_id'] . '">' . ucwords($name) . '</option>';
		}
	}
	
	function get_class_students_mass($class_id)
	{
		$students = $this->db->get_where('enroll', array(
						'class_id' => $class_id,
						'year' => $this->db->get_where('settings', array('type' => 'running_year'))->row()->description
					))->result_array();
		echo '<div class="form-group row">
				<label for="datepicker2" class="col-sm-3 control-label"> &nbsp; Students </label>
				<div class="col-sm-9">
					<div class="card-header">
						<a class="btn btn-primary btn-sm" href="javascript:;" onclick="select()">
							Select All
						</a>
						<a class="btn btn-primary btn-sm" href="javascript:;" onclick="unselect()">
							Select None
						</a>
					</div>
					<div class="card-body">';
		
		foreach($students as $row)
		{
			$name = $this->db->get_where('student', array('student_id' => $row['student_id']))->row()->name;
			echo '		<div class="form-group clearfix">
							<div class="icheck-primary">
								<input type="checkbox" class="check" name="student_id[]" value="'.$row['student_id'].'" id="checkboxPrimary'.$row['student_id'].'">
								<label for="checkboxPrimary'.$row['student_id'].'">'.
									ucwords($name).
								'</label>
							</div>
						</div>';
		}
		
		echo '		</div>
				</div>
			</div>';
	}
	
	function get_students_by_class($class_id = '')
	{
		$account_type				= $this->session->userdata('login_type');
		$page_name					= 'student_by_class';
		$page_data['class_id']		= $class_id;
		$this->load->view('portal/'.$account_type.'/'.$page_name.'.php', $page_data);
	}
	
	/*** MANAGE TEACHERS ***/
	function teachers($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'teachers';
		$page_data['page_title'] = 'Teachers';
		$page_data['teachers']   = $this->db->get('teacher')->result_array();
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE ATTENDANCE ***/
	function manage_attendance()
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  =  'manage_attendance';
		$page_data['page_title'] =  'Manage Attendance of Class';
		$this->load->view('portal/index', $page_data);
	}
	
	function manage_attendance_view($class_id = '', $section_id = '', $timestamp = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['class_id'] = $class_id;
		$page_data['section_id'] = $section_id;
		$page_data['timestamp'] = $timestamp;
		$page_data['page_name'] = 'manage_attendance_view';
		$class_name = $this->db->get_where('class', array(
			'class_id' => $class_id
		))->row()->name;
		$section_name = $this->db->get_where('section', array(
			'section_id' => $section_id
		))->row()->name;
		$page_data['page_title'] = 'Manage Attendance of Class'.' '.$class_name.' : Section'.' '.$section_name;
		$this->load->view('portal/index', $page_data);
	}
	
	function attendance_selector()
	{
		$running_year       = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
		$data['class_id']   = $this->input->post('class_id');
		$data['year']       = $running_year;
		$data['timestamp']  = strtotime($this->input->post('timestamp'));
		$data['section_id'] = $this->input->post('section_id');
		
		$query = $this->db->get_where('attendance', array(
			'class_id'		=> $data['class_id'],
			'section_id'	=> $data['section_id'],
			'year'			=> $data['year'],
			'timestamp'		=> $data['timestamp']
		));
		if($query->num_rows() < 1)
		{
			$students = $this->db->get_where('enroll', array(
				'class_id'		=> $data['class_id'],
				'section_id'	=> $data['section_id'],
				'year'			=> $data['year']
			))->result_array();
			
			foreach($students as $row)
			{
				$attn_data['class_id']   = $data['class_id'];
				$attn_data['year']       = $data['year'];
				$attn_data['timestamp']  = $data['timestamp'];
				$attn_data['section_id'] = $data['section_id'];
				$attn_data['student_id'] = $row['student_id'];
				$this->db->insert('attendance', $attn_data);
			}
		}
		
		redirect(base_url().'index.php?teacher/manage_attendance_view/'.$data['class_id'].'/'.$data['section_id'].'/'.$data['timestamp'], 'refresh');
	}
	
	function attendance_update($class_id = '', $section_id = '', $timestamp = '')
	{
		$attendance_of_students = $this->db->get_where('attendance', array(
			'class_id'		=> $class_id,
			'section_id'	=> $section_id,
			'year'			=> $this->db->get_where('settings', array('type' => 'running_year'))->row()->description,
			'timestamp'		=> $timestamp
		))->result_array();
		
		foreach($attendance_of_students as $row)
		{
			$attendance_status = $this->input->post('status_'.$row['attendance_id']);
			$where = array('attendance_id' => $row['attendance_id']);
			$this->db->update('attendance', $where, array('status' => $attendance_status));
			/*
			if ($attendance_status == 2)
			{
				if ($active_sms_service != '' || $active_sms_service != 'disabled')
				{
					$student_name   = $this->db->get_where('student', array('student_id' => $row['student_id']))->row()->name;
					$parent_id      = $this->db->get_where('student', array('student_id' => $row['student_id']))->row()->parent_id;
					$message        = 'Your child' . ' ' . $student_name . 'is absent today.';
					if($parent_id != null && $parent_id != 0){
						$receiver_phone = $this->db->get_where('parent', array('parent_id' => $parent_id))->row()->phone;
						if($receiver_phone != '' || $receiver_phone != null){
							$this->sms_model->send_sms($message,$receiver_phone);
						} else{
							$this->session->set_flashdata('error_message', get_phrase('parent_phone_number_is_not_found'));
						}
					} else{
						$this->session->set_flashdata('error_message', get_phrase('parent_phone_number_is_not_found'));
					}
				}
			}
			*/
		}
		$this->session->set_flashdata('flash_message', 'Attendance Updated');
		redirect(base_url().'index.php?teacher/manage_attendance_view/'.$class_id.'/'.$section_id.'/'.$timestamp, 'refresh');
	}
	
	//	ATTENDANCE REPORT	//
	function attendance_report()
	{
		$page_data['month']        = date('m');
		$page_data['page_name']    = 'attendance_report';
		$page_data['page_title']   = 'Attendance Report';
		$this->load->view('portal/index', $page_data);
	}
	
	function attendance_report_view($class_id = '', $section_id = '', $month = '', $sessional_year = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$class_name						= $this->db->get_where('class', array('class_id' => $class_id))->row()->name;
		$section_name					= $this->db->get_where('section', array('section_id' => $section_id))->row()->name;
		$page_data['class_id']			= $class_id;
		$page_data['section_id']		= $section_id;
		$page_data['month']				= $month;
		$page_data['sessional_year']	= $sessional_year;
		$page_data['page_name']			= 'attendance_report_view';
		$page_data['page_title']		= 'Attendance Report of Class '.$class_name.' : Section '.$section_name;
		$this->load->view('portal/index', $page_data);
	}
	
	function attendance_report_print_view($class_id ='', $section_id = '', $month = '', $sessional_year = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['class_id']			= $class_id;
		$page_data['section_id']		= $section_id;
		$page_data['month']				= $month;
		$page_data['sessional_year']	= $sessional_year;
		$this->load->view('portal/teacher/attendance_report_print_view', $page_data);
	}
	
	function attendance_report_selector()
	{
		if($this->input->post('class_id') == '' || $this->input->post('sessional_year') == '')
		{
			$this->session->set_flashdata('error_message', 'Please Make Sure Class and Sessional Year are Selected');
			redirect(base_url() . 'index.php?teacher/attendance_report', 'refresh');
		}
		
		$data['class_id']		= $this->input->post('class_id');
		$data['section_id']		= $this->input->post('section_id');
		$data['month']			= $this->input->post('month');
		$data['sessional_year']	= $this->input->post('sessional_year');
		redirect(base_url() . 'index.php?teacher/attendance_report_view/'.$data['class_id'].'/'.$data['section_id'].'/'.$data['month'].'/'.$data['sessional_year'], 'refresh');
	}
	
	/*** MANAGE SUBJECTS ***/
	function subject($class_id = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		// get the first class
		if($class_id == '')
			$class_id	=	$this->db->get('class')->first_row()->class_id;
		
		$page_data['page_name']  = 'subject';
		$page_data['page_title'] = 'Manage Subjects';
		$page_data['class_id']   = $class_id;
		$this->load->view('portal/index', $page_data);
	}
	
	//	ACADEMIC SYLLABUS	//
	function academic_syllabus($class_id = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		// detect the first class
		if ($class_id == '')
			$class_id	= $this->db->get('class')->first_row()->class_id;
		
		$page_data['page_name']  = 'academic_syllabus';
		$page_data['page_title'] = 'Academic Syllabus';
		$page_data['class_id']   = $class_id;
		$this->load->view('portal/index', $page_data);
	}
	
	function upload_academic_syllabus()
	{
		$data['academic_syllabus_code']	=  	substr(md5(rand(0, 1000000)), 0, 7);
		if ($this->input->post('description') != null) {
			$data['description'] = $this->input->post('description');
		}
		$data['title']					=	$this->input->post('title');
		$data['class_id']				=	$this->input->post('class_id');
		$data['subject_id']				=	$this->input->post('subject_id');
		$data['uploader_type']			=	$this->session->userdata('login_type');
		$data['uploader_id']			=	$this->session->userdata('login_user_id');
		$data['year']					=	$this->db->get_where('settings',array('type'=>'running_year'))->row()->description;
		$data['timestamp']				=	strtotime(date("Y-m-d H:i:s"));
		//uploading file
		$upload_path   =  'uploads/syllabus/';
		$file_name = $_FILES['file_name']['name'];
		$file_type = '.'.strtolower(pathinfo($upload_path.$file_name, PATHINFO_EXTENSION));
		move_uploaded_file($_FILES['file_name']['tmp_name'], $upload_path.trim($data['title']).$file_type);
		
		$data['file_name'] = trim($data['title']).$file_type;
		
		$this->db->insert('academic_syllabus', $data);
		$this->session->set_flashdata('flash_message', 'Syllabus Uploaded');
		redirect(base_url() . 'index.php?teacher/academic_syllabus/'.$data['class_id'], 'refresh');
	}
	
	function download_academic_syllabus($academic_syllabus_code)
	{
		set_time_limit(0);
		
		$file_name = $this->db->get_where('academic_syllabus', array(
			'academic_syllabus_code' => $academic_syllabus_code
		))->row()->file_name;
		
		$file = "uploads/syllabus/".$file_name;
		
		force_download($file, $file_name);
	}
	
	function delete_academic_syllabus($academic_syllabus_code)
	{
		$file_name = $this->db->get_where('academic_syllabus', array(
			'academic_syllabus_code' => $academic_syllabus_code
		))->row()->file_name;
		
		if(file_exists('uploads/syllabus/'.$file_name)) {
			unlink('uploads/syllabus/'.$file_name);
		}
		$where = array('academic_syllabus_code' => $academic_syllabus_code);
		$this->db->delete('academic_syllabus', $where);
		
		$this->session->set_flashdata('flash_message', 'Data Deleted');
		redirect(base_url() . 'index.php?teacher/academic_syllabus', 'refresh');
	}
	
	//	STUDY MATERIAL	//
	function study_material($task = "", $document_id = "")
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Create Study Material
		if ($task == "create")
		{
			save_study_material_info();
			$this->session->set_flashdata('flash_message', 'Study Material Info Saved Successfully');
			redirect(base_url() . 'index.php?teacher/study_material', 'refresh');
		}
		//	Update Study Material
		if ($task == "update")
		{
			update_study_material_info($document_id);
			$this->session->set_flashdata('flash_message', 'Study Material Info Updated Successfully');
			redirect(base_url() . 'index.php?teacher/study_material', 'refresh');
		}
		//	Delete Study Material
		if ($task == "delete")
		{
			delete_study_material_info($document_id);
			$this->session->set_flashdata('flash_message', 'Study Material Info Deleted');
			redirect(base_url() . 'index.php?teacher/study_material', 'refresh');
		}
		
		$data['page_name']              = 'study_material';
		$data['page_title']             = 'Study Material';
		$data['study_material_info']    = select_study_material_info();
		$this->load->view('portal/index', $data);
	}
	
	function download_study_material($document_id)
	{
		set_time_limit(0);
		
		$file_name = $this->db->get_where('document', array(
			'document_id' => $document_id
		))->row()->file_name;
		
		$file = "uploads/document/".$file_name;
		
		force_download($file, $file_name);
	}
	
	/*** MANAGE CLASS ROUTINE ***/
	function class_routine_view($class_id = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		// get the first class
		if($class_id == '')
			$class_id	=	$this->db->get('class')->first_row()->class_id;
		
		$page_data['page_name']  = 'class_routine_view';
		$page_data['page_title'] = 'Manage Class Routine';
		$page_data['class_id']  =   $class_id;
		$this->load->view('portal/index', $page_data);
	}
	
	/*** MANAGE EXAM MARKS ***/
	function marks_manage()
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  =   'marks_manage';
		$page_data['page_title'] = 'Manage Exam Marks';
		$this->load->view('portal/index', $page_data);
	}
	
	function marks_manage_view($exam_id = '', $class_id = '', $section_id = '', $subject_id = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['exam_id']    =   $exam_id;
		$page_data['class_id']   =   $class_id;
		$page_data['subject_id'] =   $subject_id;
		$page_data['section_id'] =   $section_id;
		$page_data['page_name']  =   'marks_manage_view';
		$page_data['page_title'] = 'Manage Exam Marks';
		$this->load->view('portal/index', $page_data);
	}
	
	function marks_selector()
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$data['exam_id']    = $this->input->post('exam_id');
		$data['class_id']   = $this->input->post('class_id');
		$data['section_id'] = $this->input->post('section_id');
		$data['subject_id'] = $this->input->post('subject_id');
		$data['year']       = $this->db->get_where('settings', array('type'=>'running_year'))->row()->description;
		if($data['class_id'] != '' && $data['exam_id'] != '')
		{
			$query = $this->db->get_where('mark', array(
				'exam_id' => $data['exam_id'],
				'class_id' => $data['class_id'],
				'section_id' => $data['section_id'],
				'subject_id' => $data['subject_id'],
				'year' => $data['year']
			));
			
			if($query->num_rows() < 1)
			{
				$students = $this->db->get_where('enroll', array(
					'class_id' => $data['class_id'],
					'section_id' => $data['section_id'],
					'year' => $data['year']
				))->result_array();
				
				foreach($students as $row)
				{
					$data['student_id'] = $row['student_id'];
					$this->db->insert('mark', $data);
				}
			}
			
			redirect(base_url() . 'index.php?teacher/marks_manage_view/'.$data['exam_id'].'/'.$data['class_id'].'/'.$data['section_id'].'/'.$data['subject_id'], 'refresh');
		} else
		{
			$this->session->set_flashdata('error_message', 'Select All The Fields');
			$page_data['page_name']		= 'marks_manage';
			$page_data['page_title']	= 'Manage Exam Marks';
			$this->load->view('portal/index', $page_data);
		}
	}
	
	function marks_update($exam_id = '', $class_id = '', $section_id = '', $subject_id = '')
	{
		if($class_id != '' && $exam_id != '')
		{
			$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
			$marks_of_students = $this->db->get_where('mark', array(
				'exam_id' => $exam_id,
				'class_id' => $class_id,
				'section_id' => $section_id,
				'year' => $running_year,
				'subject_id' => $subject_id
			))->result_array();
			
			foreach($marks_of_students as $row)
			{
				$mark_total = $this->input->post('mark_total_'.$row['mark_id']);
				$obtained_marks = $this->input->post('marks_obtained_'.$row['mark_id']);
				$comment = $this->input->post('comment_'.$row['mark_id']);
				$where = array('mark_id' => $row['mark_id']);
				$this->db->update('mark', $where, array('mark_obtained' => $obtained_marks, 'mark_total' => $mark_total, 'comment' => $comment));
			}
			
			$this->session->set_flashdata('flash_message', 'Marks Updated');
			redirect(base_url().'index.php?teacher/marks_manage_view/'.$exam_id.'/'.$class_id.'/'.$section_id.'/'.$subject_id , 'refresh');
		} else
		{
			$this->session->set_flashdata('error_message', 'Select All The Fields');
			$page_data['page_name']		= 'marks_manage';
			$page_data['page_title']	= 'Manage Exam Marks';
			$this->load->view('portal/index', $page_data);
		}
	}
	
	function mark_class_section($class_id)
	{
		$sections = $this->db->get_where('section', array('class_id' => $class_id))->result_array();
		foreach($sections as $row)
		{
			echo '<option value="' . $row['section_id'] . '">' . ucwords($row['name']) .' ('. ucwords($row['nick_name']) . ') </option>';
		}
	}
	
	function mark_class_section_subject($class_id, $section_id)
	{
		$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
		$sql = 'SELECT * FROM `subject` WHERE'.
				' `class_id` = "'.$class_id.
				'" AND `year` = "'.$running_year.
				'" AND (`section_id` = "'.$section_id.'" OR `section_id` = 0)';
		$subjects = $this->db->query($sql)->result_array();
		foreach($subjects as $row)
		{
			echo '<option value="' . $row['subject_id'] . '">' . ucwords($row['name']) . '</option>';
		}
	}
	
	/*** MANAGE LIBRARY/BOOKS ***/
	function book($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		$page_data['page_name']  = 'book';
		$page_data['page_title'] = 'Manage Library Books';
		$page_data['books']      = $this->db->get('book')->result_array();
		$this->load->view('portal/index', $page_data);
	}
	
	function download_book($book_id)
	{
		set_time_limit(0);
		
		$file_name = $this->db->get_where('book', array(
			'book_id' => $book_id
		))->row()->file_name;
		
		$file = "uploads/library/".$file_name;
		
		force_download($file, $file_name);
	}
	
	/*** MANAGE OWN PROFILE AND CHANGE PASSWORD ***/
	function manage_profile($param1 = '', $param2 = '', $param3 = '')
	{
		if($this->session->userdata('teacher_login') != 1)
			redirect(base_url() . 'index.php?login', 'refresh');
		
		//	Update Profile
		if($param1 == 'update_profile_info')
		{
			$data['name']  = $this->input->post('name');
			$data['email'] = $this->input->post('email');
			
			$teacher_id = $this->session->userdata('teacher_id');
			
			$validation = email_validation_for_edit($data['email'], $teacher_id, 'teacher');
			if($validation == 1)
			{
				$where = array('teacher_id' => $this->session->userdata('teacher_id'));
				$this->db->update('teacher', $where, $data);
                move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/teacher_image/'.$this->session->userdata('teacher_id').'.jpg');
				$this->session->set_flashdata('flash_message', 'Account Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'This Email ID is not available');
			}
			redirect(base_url() . 'index.php?teacher/manage_profile/', 'refresh');
		}
		//	Change Password
		if($param1 == 'change_password')
		{
			$data['password']		= $this->input->post('password');
			$data['new_password']	= $this->input->post('new_password');
			$data['cnew_password']	= $this->input->post('cnew_password');
			
			$current_password = $this->db->get_where('teacher', array(
				'teacher_id' => $this->session->userdata('teacher_id')
			))->row()->password;
			if($current_password == $data['password'] && $data['new_password'] == $data['cnew_password'])
			{
				$where = array('teacher_id' => $this->session->userdata('teacher_id'));
				$this->db->update('teacher', $where, array(
					'password' => $data['new_password']
				));
				$this->session->set_flashdata('flash_message', 'Password Updated');
			} else
			{
				$this->session->set_flashdata('error_message', 'Password Mismatch');
			}
			redirect(base_url() . 'index.php?teacher/manage_profile/', 'refresh');
		}
		
		$page_data['page_name']  = 'manage_profile';
		$page_data['page_title'] = 'Manage Profile';
		$page_data['edit_data']  = $this->db->get_where('teacher', array(
			'teacher_id' => $this->session->userdata('teacher_id')
		))->result_array();
		$this->load->view('portal/index', $page_data);
	}
	

}