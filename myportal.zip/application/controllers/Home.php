<?php

class Home extends Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	public function index()
	{
		$data['page_name'] = 'home';
		$this->load->view('home/index', $data);
	}
}