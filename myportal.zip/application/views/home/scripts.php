	<!-- REQUIRED SCRIPTS -->
	
	<!-- Bootstrap -->
	<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- AdminLTE -->
	<script src="dist/js/adminlte.js"></script>
	
	<!-- OPTIONAL SCRIPTS -->
	<script src="plugins/chart.js/Chart.min.js"></script>
	<script src="dist/js/demo.js"></script>
	<script src="dist/js/pages/dashboard3.js"></script>
