<?php
$system_name = $this->db->get_where('settings' , array('type'=>'system_name'))->row()->description;
?>
		<!-- Navbar -->
		<nav class="main-header navbar navbar-expand navbar-light navbar-white">
			<div class="container">
				<span class="navbar-brand">
					<img src="uploads/logo.png" alt="Logo" class="brand-image">
					<span class="brand-text font-weight-light"> <?php echo ucwords($system_name); ?> </span>
				</span>
			</div>
		</nav>
		<!-- /.navbar -->
		

		<section class="content home-box">
			<div class="container-fluid">
				<div class="row">
					
					<div class="col-md-6">
						<div class="home-content">
							<h1>The <br>
							<span class="text-primary">INTEGRATED</span> <br>
							School Software</h1>
							<p>The best school management system for Nursery and High Schools. </p>
							<!--<a class="btn btn-primary rounded-pill" href="">Sign Up</a>
							<a class="btn btn-outline-primary rounded-pill" href="<?php //echo base_url() ?>index.php?login">Sign In</a>-->
							<a class="btn btn-primary rounded-pill" href="<?php echo base_url() ?>index.php?login">Sign in now</a>
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="home-img">
							<img class="card-img-top img-fluid" src="dist/img/school.png" alt="">
						</div>
					</div>
					
				</div>
			</div>
		</section>
