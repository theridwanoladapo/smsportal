
		<section class="content home-box mt-6">
			<div class="container-fluid">
				<div class="row">
					
					<div class="col-md-6">
						<div class="login-box">
							<div class="login-logo">
							<a href="../../index2.html"><!--img src="dist/img/author.jpg" style="max-width:80px"-->Ridwanulahi IS</a>
							</div>
							<!-- /.login-logo -->
							<div class="card">
								<div class="card-body login-card-body">
									<p class="login-box-msg">Sign in to start your session</p>
									
									<form method="post" action="<?php echo base_url();?>index.php?login/validate_login">
										<label for="" class="control-label"> Email </label>
										<div class="input-group mb-4">
											<input type="email" class="form-control" placeholder="Your email address">
											<div class="input-group-append">
												<div class="input-group-text">
													<span class="fas fa-envelope"></span>
												</div>
											</div>
										</div>
										<label for="" class="control-label"> Password </label>
										<div class="input-group mb-4">
											<input type="password" class="form-control" placeholder="Your password">
											<div class="input-group-append">
												<div class="input-group-text">
													<span class="fas fa-lock"></span>
												</div>
											</div>
										</div>
										<div class="input-group mb-4">
											<button type="submit" class="btn btn-primary btn-block rounded-pill">Sign In</button>
										</div>
									</form>
									
									<p class="mb-1">
										<a href="#">I forgot my password</a>
									</p>
								</div>
								<!-- /.login-card-body -->
							</div>
						</div>
						<!-- /.login-box -->
					</div>
					
					<div class="col-md-6">
						<div class="home-img">
							<img class="card-img-top img-fluid" src="dist/img/school.png" alt="">
						</div>
					</div>
					
				</div>
			</div>
		</section>


<!--
<div class="login-box">
	<div class="card">
		<div class="card-body login-card-body">
			<!-- form start --
			<form role="form" method="post" >
				<div class="form-group row">
					<label for="inputAdminEmail" class="control-label"> Admin Email </label>
					<input type="email" class="form-control" id="inputAdminEmail" name="email">
				</div>
				<div class="form-group row">
					<label for="inputAdminPass" class="control-label"> Admin Password </label>
					<input type="password" class="form-control" id="inputAdminPass" name="password">
				</div>
				<button type="submit" class="btn btn-block btn-primary"> Set me Up </button>
			</form>
		</div>
	</div>
</div>
-->