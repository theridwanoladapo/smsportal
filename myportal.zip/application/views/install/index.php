<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<!-- Tell the browser to be responsive to screen width -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<link rel="shortcut icon" href="uploads/GISMlogo.png">
		
	<title> Installation | Genuine School Management System </title>
	<?php include 'styles.php'; ?>
</head>

<body class="hold-transition layout-top-nav layout-footer-fixed">
	
	<div class="wrapper">
		<!-- Navbar -->
		<nav class="main-header navbar navbar-expand navbar-light navbar-white">
			<div class="container">
				<span class="navbar-brand">
					<img src="dist/img/GISMlogo.png" alt="GISMS Logo" class="brand-image img-circle elevation-1" style="opacity: .8">
					<span class="brand-text font-weight-light"> Genuine School Management System </span>
				</span>
				
				<!-- Right navbar links -->
				<span class="navbar-brand">
					<span class="brand-text font-weight-light"> INSTALLATION </span>
				</span>
			</div>
		</nav>
		<!-- /.navbar -->
		
		<!-- Main content -->
		<?php
			include 'main/'.$page_name.'.php';
		?>
		<!-- /.content -->
		
		<!-- Main Footer -->
		<footer class="main-footer">
			Copyright &copy; 2019 <a href=""> GenuineISMS.io </a>.
			All rights reserved.
			<div class="float-right d-none d-sm-inline-block">
				<b>Version</b> 1.0.0
			</div>
		</footer>
	</div>
	<!-- ./wrapper -->

	<?php include 'scripts.php'; ?>

</body>
</html>