		<!-- Main content -->
		<section class="content install-box">
			<div class="card card-success card-outline">
				<div class="card-body">
					<h5 class="mb-3 text-success"> Success!! </h5>
					<p class="card-text">
					Installation was successful. Please Sign In to continue..
					</p>
					
					<table class="table mt-5 mb-4">
						<tbody>
							<tr>
								<th> Administrator Email </td>
								<td> <?php echo $admin_email ?> </td>
							</tr>
							<tr>
								<th> Password </td>
								<td> Your chosen password </td>
							</tr>
						</tbody>
					</table>
					
					<a href="<?php echo base_url();?>index.php?install/success/login" class="btn btn-primary">
						&nbsp; <i class="fas fa-sign-in-alt"></i> &nbsp; Sign In &nbsp;
					</a>
					
				</div>
			</div>
			
			<div class="text-center">
				Need help? <a href=""> Contact us </a>.
			</div>
		</section>