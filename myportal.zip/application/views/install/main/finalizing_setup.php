		<!-- Main content -->
		<section class="content install-box">
			<div class="card card-success card-outline">
				<div class="card-header text-center">
					<i class="fas fa-thumbs-up fa-3x text-success mb-4"></i>
					<h5 class="mb-3"> Congratulations!! The installation was successful </h5>
					
					<p class="card-text">
					<strong>Before you start using your application, make it yours. Set your application name and title, admin login
					email and password. Remember the login credentials which you will need later on for signing into your account.
					After this step, you will be redirected to application's login page.</strong>
					</p>
				</div>
				<div class="card-body">
					<!-- form start -->
					<form class="form-horizontal" method="post" action="<?php echo base_url();?>index.php?install/finalizing_setup/setup_admin">
						<div class="card-body">
							<div class="form-group row">
								<label for="inputSchName" class="col-sm-3 control-label"> School Name </label>
								<div class="col-sm-5">
									<input type="text" class="form-control text-capitalize" id="inputSchName" name="system_name" required>
								</div>
								<p class="col-sm-4"> The name of your school </p>
							</div>
							<div class="form-group row">
								<label for="inputSchTitle" class="col-sm-3 control-label"> School Title </label>
								<div class="col-sm-5">
									<input type="text" class="form-control text-uppercase" id="inputSchTitle" name="system_title" required>
								</div>
								<p class="col-sm-4"> Title for your application </p>
							</div>
							<div class="form-group row">
								<label for="inputAdminName" class="col-sm-3 control-label"> Admin Name </label>
								<div class="col-sm-5">
									<input type="text" class="form-control text-capitalize" id="inputAdminName" name="name" required>
								</div>
								<p class="col-sm-4"> Fullname of Administrator </p>
							</div>
							<div class="form-group row">
								<label for="inputAdminEmail" class="col-sm-3 control-label"> Admin Email </label>
								<div class="col-sm-5">
									<input type="email" class="form-control" id="inputAdminEmail" name="email" required>
								</div>
								<p class="col-sm-4"> Email address for Administrator login</p>
							</div>
							<div class="form-group row">
								<label for="inputAdminPass" class="col-sm-3 control-label"> Admin Password </label>
								<div class="col-sm-5">
									<input type="password" class="form-control" id="inputAdminPass" name="password" required>
								</div>
								<p class="col-sm-4"> Admin login password </p>
							</div>
						</div>
						<!-- /.card-body -->
						<div class="card-footer">
							<button type="submit" class="btn btn-primary"> &nbsp; Set me Up &nbsp; </button>
						</div>
						<!-- /.card-footer -->
					</form>
				</div>
			</div>
			
			<div class="text-center">
			Need help? <a href=""> Contact us </a>.
			</div>
		</section>