		<!-- Main content -->
		<section class="content install-box">
			<div class="card card-primary card-outline">
				<div class="card-body">
					<p class="card-text">
					Welcome to <strong>Genuine School Management System</strong> Installation. You will need to know the following items before proceeding.
					</p>
					<ol>
						<li> Database Name </li>
						<li> Database Username </li>
						<li> Database Password </li>
						<li> Database Hostname </li>
					</ol>
					<p>
					We are going to use the above information to write database.php file which will connect the application to your
					database. During the installation process, we 	will check if files that are needed to be written
					<strong>(application/config/database.php & application/config/routes.php)</strong> have <strong>write permission.</strong>
					we will also check if <strong>curl</strong> and <strong>php mail functions</strong> are enabled on your server or not.
					</p>
					<p>
					Gather the information mentioned above hitting the start installation button. if you are ready....
					</p>
					
					<a href="<?php echo base_url() ?>index.php?install/step1" class="btn btn-primary">
						&nbsp; Start Installation Process &nbsp;
					</a>
				</div>
			</div>
			
			<div class="text-center">
				Need help? <a href=""> Contact us </a>.
			</div>
		</section>