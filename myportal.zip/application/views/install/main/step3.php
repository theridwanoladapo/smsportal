
		<section class="content install-box">
			<div class="card card-primary card-outline">
				<div class="card-body">
					<p class="card-text">
						Your database is successfully connected</strong>. All you need to do now is
						<strong>hit the 'Install' button</strong>.
						The auto installer will run a sql file, will do all the tiresome works and set up your application automatically.
					</p>
					
					<div id="loader" class="pt-3">
						<img src="dist/img/loader.gif" alt="" width="20">
						&nbsp; Importing database ....
					</div>
				</div>
				<!-- /.card-body -->
				
				<div class="card-footer">
					<button type="submit" id="install_button" class="btn btn-primary">
						<i class="fas fa-download"></i> &nbsp; Install &nbsp;
					</button>
				</div>
				<!-- /.card-footer -->
			</div>
			
			<div class="text-center">
				Need help? <a href=""> Contact us </a>.
			</div>
		</section>
		
		<script type="text/javascript">
			$(document).ready(function(){
				$("#loader").hide();
				$("#install_button").click(function(){
					$("#loader").fadeIn();
					setTimeout(function(){
						window.location.href = '<?php echo base_url();?>index.php?install/step3/confirm_install';
					}, 15000);
				});
			});
		</script>
	