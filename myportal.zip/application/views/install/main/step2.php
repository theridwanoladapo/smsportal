		<!-- Main content -->
		<section class="content install-box">
			<?php if(isset($error_con_fail)){ ?>
			<div class="card-header bg-danger">
				<p class="card-text">
				<?php echo $error_con_fail; ?>
				</p>
			</div>	
			<?php } ?>
			<?php if(isset($error_nodb)){ ?>
			<div class="card-header bg-danger">
				<p class="card-text">
				<?php echo $error_nodb; ?>
				</p>
			</div>	
			<?php } ?>
			<div class="card card-primary card-outline">
				<div class="card-header">
					<p class="card-text">
					Below you should enter your database connection details. If you're not sure about these, contact your host.
					</p>
				</div>	
				<div class="card-body">
					<!-- form start -->
					<form class="form-horizontal" method="post" action="<?php echo base_url();?>index.php?install/step2/configure_database">
						<div class="card-body">
							<div class="form-group row">
								<label for="inputEmail3" class="col-sm-3 control-label"> Database Name </label>
								<div class="col-sm-5">
									<input type="text" class="form-control" name="dbname" required>
								</div>
								<p class="col-sm-4"> The name of the database you want to use with this application </p>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-3 control-label"> Database Username </label>
								<div class="col-sm-5">
									<input type="text" class="form-control" name="username" required>
								</div>
								<p class="col-sm-4"> Your database Username </p>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-3 control-label"> Database Password </label>
								<div class="col-sm-5">
									<input type="password" class="form-control" name="password">
								</div>
								<p class="col-sm-4"> Your database Password </p>
							</div>
							<div class="form-group row">
								<label for="inputPassword3" class="col-sm-3 control-label"> Database Hostname </label>
								<div class="col-sm-5">
									<input type="text" class="form-control" name="hostname" required>
								</div>
								<p class="col-sm-4"> Your database Hostname </p>
							</div>
						</div>
						<!-- /.card-body -->
						<div class="card-footer">
							<button type="submit" class="btn btn-primary"> &nbsp; Continue &nbsp; </button>
						</div>
						<!-- /.card-footer -->
					</form>
				</div>
			</div>
			
			<div class="text-center">
			Need help? <a href=""> Contact us </a>.
			</div>
		</section>