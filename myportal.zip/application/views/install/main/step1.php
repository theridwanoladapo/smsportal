<?php
	$db_file_write_perm = is_writable('application/config/database.php');
	$routes_file_write_perm = is_writable('application/config/routes.php');
	
	if ($db_file_write_perm == false || $routes_file_write_perm == false)
	{
		$valid = false;
	}
	else
	{
		$valid = true;
	}
?>

		<!-- Main content -->
		<section class="content install-box">
			<div class="card card-primary card-outline">
				<div class="card-body">
					<p class="card-text">
					We ran diagnosis on your server. Review the items that have a red mark on it. If everything is green, you are good to go to the next step.
					</p>
					<ul class="list-unstyled pl-4">
						<li>
							<strong>
								<?php if($db_file_write_perm == true){ ?>
								&nbsp; <i class="fas fa-check text-success"></i> &nbsp;
								<?php } else{ ?>
								&nbsp; <i class="fas fa-times text-danger"></i> &nbsp;
								<?php } ?>
								application/config/database.php
							</strong>
							: file has write permission
						</li>
						<li>
							<strong>
								<?php if($routes_file_write_perm == true){ ?>
								&nbsp; <i class="fas fa-check text-success"></i> &nbsp;
								<?php } else{ ?>
								&nbsp; <i class="fas fa-times text-danger"></i> &nbsp;
								<?php } ?>
								application/config/routes.php
							</strong>
							: file has write permission
						</li>
					</ul>
					<p>
					<strong>To continue the installation process, all the above requirements are needed to be checked.</strong>
					</p>
					
					<?php if($valid == true){ ?>
					<a href="<?php echo base_url() ?>index.php?install/step2" class="btn btn-primary">
						&nbsp; Continue &nbsp;
					</a>
					<?php } ?>
					
					<?php if($valid != true){ ?>
					<a href="<?php echo base_url() ?>index.php?install/step2" class="btn btn-primary disabled">
						&nbsp; Continue &nbsp;
					</a>
					<a href="<?php echo base_url() ?>index.php?install/step1" class="btn btn-primary">
						<i class="fas fa-sync"></i> &nbsp; Reload &nbsp;
					</a>
					<?php } ?>
				</div>
			</div>
			
			<div class="text-center">
				Need help? <a href=""> Contact us </a>.
			</div>
		</section>