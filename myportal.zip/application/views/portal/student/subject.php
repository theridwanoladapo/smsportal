<?php
	$student_id = $data['student_id'];
	$where	= array('student_id' => $student_id);
	$student_info	= $this->db->get_where('enroll', $where)->row();
	$class_id = $student_info->class_id;
	$section_id = $student_info->section_id;
	$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<div class="container-fluid">
					<div class="row mb-2">
						<div class="col-sm-6">
						<h5 class="m-0 text-dark"> <?php echo $page_title; ?> </h5>
						</div>
						<div class="col-sm-6">
							<ol class="breadcrumb float-sm-right">
								<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>index.php?student/dashboard">Dashboard</a></li>
								<li class="breadcrumb-item active"> Subjects </li>
							</ol>
						</div>
					</div>
				</div><!-- /.container-fluid -->
			</section>
			
			<!-- Main content -->
			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-12">
							<!-- Default box -->
							<div class="card card-primary card-outline">
								<div class="card-header">
									<div class="card-title">
										Subject List
									</div>
								</div>
								
								<div class="card-body">
									<table id="subjects" class="table table-bordered table-striped projects">
										<thead>
											<tr>
												<th> # </th>
												<th> Subject Name </th>
												<th> Teacher </th>
											</tr>
										</thead>
										
										<tbody>
										<?php
											$count = 1;
											$sql = 'SELECT * FROM `subject` WHERE'.
													' `class_id` = "'.$class_id.
													'" AND `year` = "'.$running_year.
													'" AND (`section_id` = "'.$section_id.'" OR `section_id` = 0)';
											$subjects = $this->db->query($sql)->result_array();
											foreach ($subjects as $row):
										?>
											<tr>
												<td><?php echo $count++; ?></td>
												<td><?php echo ucwords($row['name']);?></td>
												<td>
												<?php
													if($row['teacher_id'] != '' || $row['teacher_id'] != 0)
														echo ucwords(get_type_name_by_id('teacher' ,$row['teacher_id']));
												?>
												</td>
											</tr>
										<?php
											endforeach;
										?>
										</tbody>
									</table>
								</div>
								<!-- /.card-body -->
							</div>
							<!-- /.card -->
						</div>
					</div>
				</div>
			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
		
		<script type="text/javascript">
			$(function () {
				// Initialize DataTable Elements
				$('#section').DataTable({
					"paging": false,
					"lengthChange": false,
					"searching": false,
					"ordering": false,
					"info": false,
					"autoWidth": true
				});
			});
		</script>