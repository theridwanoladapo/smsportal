		<!-- Main Sidebar Container -->
		<aside class="main-sidebar sidebar-light-primary elevation-4">
			<!-- Brand Logo -->
			<a href="" class="brand-link">
				<img src="uploads/logo.png" alt="AdminLTE Logo" class="brand-image elevation-3 bg-white">
				<span class="brand-text font-weight-light"> <?php echo ucwords($system_title); ?> </span>
			</a>
			
			<!-- Sidebar -->
			<div class="sidebar">
				<!-- Sidebar Menu -->
				<nav class="mt-2 mb-3">
					<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?student/dashboard" class="nav-link <?php if($page_name == 'dashboard') echo 'active'; ?>">
								<i class="nav-icon fas fa-tachometer-alt"></i>
								<p> Dashboard </p>
							</a>
						</li>
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?student/subject" class="nav-link <?php if($page_name == 'subject') echo 'active'; ?>">
								<i class="nav-icon fas fa-book-reader"></i>
								<p> Subjects </p>
							</a>
						</li>
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?student/academic_syllabus" class="nav-link <?php if($page_name == 'academic_syllabus') echo 'active'; ?>">
								<i class="nav-icon fas fa-bookmark"></i>
								<p> Academic Syllabus </p>
							</a>
						</li>
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?student/study_material" class="nav-link <?php if($page_name == 'study_material') echo 'active'; ?>">
								<i class="nav-icon fas fa-book-open"></i>
								<p> Study Materials </p>
							</a>
						</li>
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?student/class_routine/" class="nav-link <?php if($page_name == 'class_routine')	echo 'active'; ?>">
								<i class="nav-icon fas fa-table"></i>
								<p> Class Routine </p>
							</a>
						</li>
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?student/results/" class="nav-link <?php if($page_name == 'results') echo 'active'; ?>">
								<i class="fas fa-chart-area nav-icon"></i>
								<p> Exam Results </p>
							</a>
						</li>
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?student/invoice" class="nav-link <?php if($page_name == 'invoice') echo 'active';?>">
								<i class="nav-icon fas fa-credit-card"></i>
								<p> Payments </p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url(); ?>index.php?student/manage_profile" class="nav-link <?php if($page_name == 'manage_profile') echo 'active';?>">
								<i class="nav-icon fas fa-user-lock"></i>
								<p> Account </p>
							</a>
						</li>
					</ul>
				</nav>
				<!-- /.sidebar-menu -->
			</div>
			<!-- /.sidebar -->
		</aside>
		