		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<div class="container-fluid">
					<div class="row mb-2">
						<div class="col-sm-6">
						<h5 class="m-0 text-dark"> <?php echo $page_title; ?> </h5>
						</div>
						<div class="col-sm-6">
							<ol class="breadcrumb float-sm-right">
								<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>index.php?student/dashboard">Dashboard</a></li>
								<li class="breadcrumb-item active"> Manage Account </li>
							</ol>
						</div>
					</div>
				</div><!-- /.container-fluid -->
			</section>
			
			<!-- Main content -->
			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-12">
							<!-- Default box -->
							<div class="card card-primary card-outline">
								<div class="card-body">
									<ul class="nav nav-tabs" id="profile-tab" role="tablist">
										<li class="nav-item">
											<a class="nav-link active" id="edit-profile-tab" data-toggle="pill" href="#edit-profile" role="tab" aria-controls="edit-profile" aria-selected="true">
											<i class="fa fa-user"></i> &nbsp; My Profile
											</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" id="chng-pass-tab" data-toggle="pill" href="#chng-pass" role="tab" aria-controls="chng-pass" aria-selected="false">
											<i class="fa fa-lock"></i> &nbsp; Change Password
											</a>
										</li>
									</ul>
									
									<div class="tab-content" id="profile-tabContent">
										<div class="tab-pane fade show active" id="edit-profile" role="tabpanel" aria-labelledby="edit-profile-tab">
											<div class="row">
												<div class="col-lg-8">
													<?php
														$profile = $data['edit_data'];
														foreach($profile as $row):
															$enroll_info = $this->db->get_where('enroll', array(
															  'student_id' => $row['student_id'], 'year' => $running_year
															))->row();
															$class = $this->db->get_where('class',
															array('class_id' => $enroll_info->class_id))->row();
															$section = $this->db->get_where('section',
															array('section_id' => $enroll_info->section_id))->row();
															$basic_info_titles = array(
																'name','parent', 'class', 'section',
																'email', 'phone', 'address', 'gender', 'birthday'
															);
															$basic_info_values = array(
																ucwords($row['name']),
																$row['parent_id'] == NULL ? '' : ucwords($this->db->get_where('parent',
																array('parent_id' => $row['parent_id']))->row()->name),
																$class->name, ucwords($section->name).' ('.ucwords($section->nick_name.')'),
																$row['email'], $row['phone'] == NULL ? '' : $row['phone'],
																$row['address'] == NULL ? '' : ucwords($row['address']),
																$row['gender'] == NULL ? '' : ucwords($row['gender']),$row['birthday']
															);
													?>
													<table class="table table-bordered mt-3">
														<tbody>
														<?php
															for($i = 0; $i < count($basic_info_titles); $i++):
														?>
															<tr>
																<td>
																	<strong><?php echo ucfirst($basic_info_titles[$i]); ?></strong>
																</td>
																<td>
																	<?php echo $basic_info_values[$i]; ?>
																</td>
															</tr>
														<?php
															endfor;
														?>
														</tbody>
													</table>
													<?php
														endforeach;
													?>
												</div>
											</div>
										</div>
										
										<div class="tab-pane fade" id="chng-pass" role="tabpanel" aria-labelledby="chng-pass-tab">
											<div class="row">
												<div class="col-lg-8">
													<!-- form start -->
													<form class="form-horizontal" method="post" autocomplete="off" action="<?php echo base_url();?>index.php?student/manage_profile/change_password">
														<div class="card-body">
															<div class="form-group row">
																<label for="inputCP" class="col-sm-4 control-label"> &nbsp; Current Password </label>
																<div class="col-sm-8">
																	<input type="password" name="password" class="form-control" id="inputCP" required>
																</div>
															</div>
															<div class="form-group row">
																<label for="inputNP" class="col-sm-4 control-label"> &nbsp; New Password </label>
																<div class="col-sm-8">
																	<input type="password" name="new_password" class="form-control" id="inputNP" required>
																</div>
															</div>
															<div class="form-group row">
																<label for="inputCNP" class="col-sm-4 control-label"> &nbsp; Confirm New Password </label>
																<div class="col-sm-8">
																	<input type="password" name="cnew_password" class="form-control" id="inputCNP" required>
																</div>
															</div>
															<div class="form-group row">
																<div class="offset-sm-4 col-sm-8">
																	<button type="submit" class="btn btn-primary"> &nbsp; Change Password &nbsp; </button>
																</div>
															</div>
														</div>
														<!-- /.card-body -->
													</form>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!-- /.card-body -->
							</div>
							<!-- /.card -->
						</div>
					</div>
				</div>
			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
		
		<!-- page script -->
		<script type="text/javascript">
			$(function () {
				// Initialize DataTable Elements
				$('#class').DataTable();
				
				// Initialize Select2 Elements
				$('.select2').select2({
					theme: 'bootstrap4'
				})
			});
		</script>