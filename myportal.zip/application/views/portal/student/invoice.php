<?php
	$student_id = $data['student_id'];
	$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<div class="container-fluid">
					<div class="row mb-2">
						<div class="col-sm-6">
						<h5 class="m-0 text-dark"> <?php echo $page_title; ?> </h5>
						</div>
						<div class="col-sm-6">
							<ol class="breadcrumb float-sm-right">
								<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>index.php?student/dashboard">Dashboard</a></li>
								<li class="breadcrumb-item active"> Invoices / Payments </li>
							</ol>
						</div>
					</div>
				</div><!-- /.container-fluid -->
			</section>
			
			<!-- Main content -->
			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">
										<h4>
										<?php echo ucwords($this->db->get_where('student', array('student_id' => $student_id))->row()->name);?>
										</h4>
									</div>
								</div>
							</div>
							<!-- Default box -->
							<div class="card card-primary card-outline">
								<div class="card-header">
									<div class="card-title">
										Invoice / Payment List
									</div>
								</div>
								
								<div class="card-body table-responsive">
									<table id="invoice_table" class="table table-bordered table-striped">
										<thead>
											<tr>
												<th> Title </th>
												<th> Description </th>
												<th> Amount </th>
												<th> Amount Paid </th>
												<th> Status </th>
												<th> Date </th>
												<th> Options </th>
											</tr>
										</thead>
										
										<tbody>
											<?php
												$count = 1;
												$where = array('student_id' => $student_id, 'year' => $running_year);
												$orderby = array('creation_timestamp' => 'DESC');
												$invoices = $this->db->get_where('invoice', $where, $orderby)->result_array();
												foreach($invoices as $row):
											?>
											<tr>
												<td><?php echo ucwords($row['title']); ?></td>
												<td><?php echo ucfirst($row['description']); ?></td>
												<td><?php echo $row['amount']; ?></td>
												<td><?php echo $row['amount_paid']; ?></td>
												<td>
													<?php if($row['due'] == 0):?>
														<button class="btn btn-success btn-xs">Paid</button>
													<?php endif;?>
													<?php if($row['due'] > 0):?>
														<button class="btn btn-danger btn-xs">Unpaid</button>
													<?php endif;?>
												</td>
												<td><?php echo date('m/d/Y', $row['creation_timestamp']); ?></td>
												<td>
													<a class="btn btn-primary btn-sm" href="javascript:;" onclick="showAjaxModal('<?php echo base_url();?>index.php?modal/popup/modal_view_invoice/<?php echo $row['invoice_id'];?>');">
														<i class="fas fa-eye"></i> &nbsp; View Invoice
													</a>
												</td>
											</tr>
											<?php
												endforeach;
											?>
										</tbody>
									</table>
								</div>
								<!-- /.card-body -->
							</div>
							<!-- /.card -->
						</div>
					</div>
				</div>
			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
		
		<!-- page script -->
		<script type="text/javascript">
			$(function () {
				// Initialize DataTable Elements
				$('#invoice_table').DataTable();
				
				// Initialize DataTable Elements
				$('#payment_table').DataTable();
				
				// Initialize Select2 Elements
				$('.select2').select2({
					theme: 'bootstrap4'
				})
			});
		</script>
