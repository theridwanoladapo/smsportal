		<!-- Main Sidebar Container -->
		<aside class="main-sidebar sidebar-dark-primary elevation-4">
			<!-- Brand Logo -->
			<a href="" class="brand-link">
				<img src="uploads/logo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3 bg-white">
				<span class="brand-text font-weight-light"> <?php echo ucwords($system_title); ?> </span>
			</a>
			
			<!-- Sidebar -->
			<div class="sidebar">
				<!-- Sidebar Menu -->
				<nav class="mt-2 mb-3">
					<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?accountant/dashboard" class="nav-link <?php if($page_name == 'dashboard') echo 'active'; ?>">
								<i class="nav-icon fas fa-tachometer-alt"></i>
								<p> Dashboard </p>
							</a>
						</li>
						<li class="nav-item has-treeview <?php if($page_name == 'income' ||
																$page_name == 'expense' ||
																$page_name == 'expense_category' ||
																$page_name == 'student_payment')
																	echo 'active menu-open';?>">
							<a href="javascript:;" class="nav-link <?php if($page_name == 'income' ||
																			$page_name == 'expense' ||
																			$page_name == 'expense_category' ||
																			$page_name == 'student_payment')
																				echo 'active';?>">
								<i class="nav-icon fas fa-briefcase"></i>
								<p> Accounting <i class="fas fa-angle-left right"></i> </p>
							</a>
							<ul class="nav nav-treeview">
								<li class="nav-item">
									<a href="<?php echo base_url(); ?>index.php?accountant/student_payment" class="nav-link <?php if($page_name == 'student_payment') echo 'active';?>">
										<i class="far fa-circle nav-icon"></i>
										<p> Create Student Payment </p>
									</a>
								</li>
								<li class="nav-item">
									<a href="<?php echo base_url(); ?>index.php?accountant/income" class="nav-link <?php if($page_name == 'income') echo 'active';?>">
										<i class="far fa-circle nav-icon"></i>
										<!--p> Student Payments </p-->
										<p> Invoices </p>
									</a>
								</li>
								<li class="nav-item">
									<a href="<?php echo base_url(); ?>index.php?accountant/expense" class="nav-link <?php if($page_name == 'expense') echo 'active';?>">
										<i class="far fa-circle nav-icon"></i>
										<p> Expense </p>
									</a>
								</li>
								<li class="nav-item">
									<a href="<?php echo base_url(); ?>index.php?accountant/expense_category" class="nav-link <?php if($page_name == 'expense_category') echo 'active';?>">
										<i class="far fa-circle nav-icon"></i>
										<p> Expense Category </p>
									</a>
								</li>
							</ul>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url(); ?>index.php?accountant/manage_profile" class="nav-link <?php if($page_name == 'manage_profile') echo 'active';?>">
								<i class="nav-icon fas fa-user-lock"></i>
								<p> Account </p>
							</a>
						</li>
					</ul>
				</nav>
				<!-- /.sidebar-menu -->
			</div>
			<!-- /.sidebar -->
		</aside>
		