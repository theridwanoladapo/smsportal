<?php
	$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
	
	$unpaid_invoices = $this->db->get_where('invoice', array('year' => $running_year, 'status' => 'unpaid'))->num_rows();
	
	$total_income = 0;
	$payments = $this->db->get_where('payment', array('year' => $running_year))->result_array();
	foreach($payments as $row)
		$total_income += $row['amount'];
	
	$total_expense = 0;
	$expenses = $this->db->get_where('expense', array('year' => $running_year))->result_array();
	foreach($expenses as $row)
		$total_expense += $row['amount'];
?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<div class="content-header">
				<div class="container-fluid">
					<div class="row mb-2">
						<div class="col-sm-6">
						<h5 class="m-0 text-dark"> <?php echo $page_title; ?> </h5>
						</div><!-- /.col -->
						<div class="col-sm-6">
							<ol class="breadcrumb float-sm-right">
								<li class="breadcrumb-item"> Dashboard </li>
							</ol>
						</div><!-- /.col -->
					</div><!-- /.row -->
				</div><!-- /.container-fluid -->
			</div>
			<!-- /.content-header -->
		
			<!-- Main content -->
			<section class="content">
				<div class="container-fluid">
					
					<!-- Small boxes -->
					<div class="row">
						<div class="col-lg-4 col-6">
							<!-- small card -->
							<div class="small-box bg-success">
								<div class="inner">
									<h3> <?php echo $unpaid_invoices; ?> </h3>
									<p> Unpaid Invoices </p>
								</div>
								<div class="icon">
									<i class="fa fa-credit-card"></i>
								</div>
							</div>
						</div>
						<!-- ./col -->
						
						<div class="col-lg-4 col-6">
							<!-- small card -->
							<div class="small-box bg-danger">
								<div class="inner">
									<h3> <?php echo $total_income; ?> </h3>
									<p> Total Income </p>
								</div>
								<div class="icon">
									<i class="fas fa-money-bill"></i>
								</div>
							</div>
						</div>
						<!-- ./col -->
						
						<div class="col-lg-4 col-6">
							<!-- small card -->
							<div class="small-box bg-primary">
								<div class="inner">
									<h3> <?php echo $total_expense; ?> </h3>
									<p> Total Expense </p>
								</div>
								<div class="icon">
									<i class="fas fa-tags"></i>
								</div>
							</div>
						</div>
						<!-- ./col -->
					</div>
					<!-- /.row -->
					
				</div><!--/. container-fluid -->
			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
		