<?php
	$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
	$student_id = $data['student_id'];
	
	$child_of_parent = $this->db->get_where('enroll' , array(
		'student_id' => $student_id , 'year' => $running_year
	))->result_array();
?>
	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- Content Header (Page header) -->
		<section class="content-header">
			<div class="container-fluid">
				<div class="row mb-2">
					<div class="col-sm-6">
						<h5 class="m-0 text-dark"> <?php echo $page_title; ?> </h5>
					</div>
					<div class="col-sm-6">
						<ol class="breadcrumb float-sm-right">
							<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>index.php?parents/dashboard">Dashboard</a></li>
							<li class="breadcrumb-item active"> Exam Results </li>
						</ol>
					</div>
				</div>
			</div><!-- /.container-fluid -->
		</section>
		
		<!-- Main content -->
		<section class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-12">
						<div class="card">
							<div class="card-header">
								<div class="card-title">
									<h4>
									<?php echo ucwords($this->db->get_where('student', array('student_id' => $row['student_id']))->row()->name);?>
									</h4>
								</div>
							</div>
						</div>
						<!-- Default box -->
						<div class="card card-primary card-outline">
							<div class="card-header">
								<div class="form-group row">
									<div class="col-md-4">
										<label for="inputClass" class="control-label"> Academic Session</label>
										<select id="year" name="year" class="form-control select3" style="width:100%;"
										onchange="get_year_exam(this.value)" required>
											<?php
												$years = $this->db->get_where('enroll',
												array('student_id' => $student_id),
												array('year', 'DESC')
												)->result_array();
												foreach ($years as $year):
											?>
											<option value="<?php echo $year['year'];?>"
											<?php if($running_year == $year['year']) echo 'selected';?>>
												<?php echo $year['year'];?>
											</option>
											<?php
												endforeach;
											?>
										</select>
									</div>
									
									<div class="col-md-4">
										<label for="inputClass" class="control-label"> Exam </label>
										<select name="exam_id" class="form-control select2" style="width:100%;"
										onchange="return get_student_exam_marks(this.value)"
										id="year_exam_holder" required>
											<option value="">Select</option>
										</select>
									</div>
								</div>
							</div>
							<div class="card-body">
								<div id="student_exam_marks_holder">
									<!-- #student_by_class_holder -->
								</div>
							</div>
							<!-- /.card-body -->
						</div>
						<!-- /.card -->
					</div>
				</div>
			</div>
		</section>
		<!-- /.content -->
	</div>
	<!-- /.content-wrapper -->
	
	<!-- page script -->
	<script type="text/javascript">
		$(function () {
			// Initialize DataTable Elements
			$('#section').DataTable({
				"paging": false,
				"lengthChange": false,
				"searching": false,
				"ordering": false,
				"info": false,
				"autoWidth": true
			});
		});
	</script>
	
	<script type="text/javascript">
		$(function () {
			//Initialize Select2 Elements
			$('.select2').select2({
				theme: 'bootstrap4'
			});
			
			//Initialize Select2 Elements
			$('.select3').select2({
				theme: 'bootstrap4',
				minimumResultsForSearch: -1
			});
		});
		
		$(document).ready(function(){
			var year = $('#year').val();
			get_year_exam(year);
		}); 
	</script>
	
	<script type="text/javascript">
		function get_year_exam(year)
		{
			$.ajax({
				url: '<?php echo base_url();?>index.php?parents/get_year_exam/' + year,
				success: function(response)
				{
					jQuery('#year_exam_holder').html(response);
				}
			});
		}
		
		function get_student_exam_marks(exam_id)
		{
			var student_id = <?php echo $student_id;?>;
			
			$.ajax({
				url: '<?php echo base_url();?>index.php?parents/get_student_exam_marks/' + exam_id + '/' + student_id,
				success: function(response)
				{
					jQuery('#student_exam_marks_holder').html(response);
				}
			});
		}
	</script>
	