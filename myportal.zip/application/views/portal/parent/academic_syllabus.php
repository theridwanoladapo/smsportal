<?php
	$student_id = $data['student_id'];
	$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<div class="container-fluid">
					<div class="row mb-2">
						<div class="col-sm-6">
						<h5 class="m-0 text-dark"> <?php echo $page_title; ?> </h5>
						</div>
						<div class="col-sm-6">
							<ol class="breadcrumb float-sm-right">
								<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>index.php?parents/dashboard">Dashboard</a></li>
								<li class="breadcrumb-item active"> Academic Syllabus </li>
							</ol>
						</div>
					</div>
				</div><!-- /.container-fluid -->
			</section>
			
			<!-- Main content -->
			<section class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-12">
							<!-- Default box -->
							<div class="card card-primary card-outline">
								<div class="card-header">
									<div class="card-title">
										<?php echo ucwords($this->db->get_where('student', array(
										'student_id' => $student_id))->row()->name);?>
									</div>
								</div>
									
								<div class="card-body">
									<table id="section" class="table table-bordered table-striped">
										<thead>
											<tr>
												<th> # </th>
												<th> Title </th>
												<th> Description </th>
												<th> Subject </th>
												<th> Uploader </th>
												<th> Date </th>
												<th> File </th>
												<th>&nbsp;</th>
											</tr>
										</thead>
										
										<tbody>
											<?php
												$count    = 1;
												$class_id = $this->db->get_where('enroll', array(
													'student_id' => $student_id, 'year' => $running_year
												))->row()->class_id;
												$syllabus = $this->db->get_where('academic_syllabus', array(
													'class_id' => $class_id, 'year' => $running_year
												))->result_array();
												foreach ($syllabus as $row):
											?>
											<tr>
												<td><?php echo $count++; ?></td>
												<td><?php echo ucwords($row['title']);?></td>
												<td><?php echo ucwords($row['description']);?></td>
												<td>
													<?php
													echo ucwords($this->db->get_where('subject', array(
													'subject_id' => $row['subject_id']
													))->row()->name);
													?>
												</td>
												<td>
													<?php
													echo ucwords($this->db->get_where($row['uploader_type'], array(
													$row['uploader_type'].'_id' => $row['uploader_id']
													))->row()->name);
													?>
												</td>
												<td><?php echo date("m/d/Y" , $row['timestamp']);?></td>
												<td>
													<?php echo substr($row['file_name'], 0, 20);?>
													<?php if(strlen($row['file_name']) > 20) echo '...';?>
												</td>
												<td>
													<a class="btn btn-primary btn-sm" href="<?php echo base_url();?>index.php?parents/download_academic_syllabus/<?php echo $row['academic_syllabus_code'];?>">
														<i class="fas fa-download"></i> Download
													</a>
												</td>
											</tr>
											<?php
												endforeach;
											?>
										</tbody>
									</table>
								</div>
								<!-- /.card-body -->
							</div>
							<!-- /.card -->
						</div>
					</div>
				</div>
			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
		
		<!-- page script -->
		<script type="text/javascript">
			$(function () {
				// Initialize DataTable Elements
				$('#section').DataTable({
					"paging": false,
					"lengthChange": false,
					"searching": false,
					"ordering": false,
					"info": false,
					"autoWidth": true
				});
			});
		</script>