<?php
	$student_id	= $data['student_id'];
	$exam_id	= $data['exam_id'];
	$year		= $data['year'];
?>
		<!-- Main content -->
		<div id="sheet<?php echo $exam_id;?>">
			<div class="card card-primary">
				<div class="card-header">
					<h5><?php echo ucwords($this->db->get_where('exam', array('exam_id' => $exam_id))->row()->name);?></h5>
				</div>
				<div class="card-body p-0">
					<?php
						$where = array('exam_id' => $exam_id, 'student_id' => $student_id, 'year' => $year);
						$marks = $this->db->get_where('mark', $where)->result_array();
						if(sizeof($marks) > 0):
					?>
					<table class="table table-bordered table-striped">
						<thead>
							<tr>
								<th style="width:30%;"> Subject </th>
								<th> Total Mark </th>
								<th> Mark Obtained </th>
								<th> Grade </th>
								<th> Comment </th>
							</tr>
						</thead>
						<tbody>
						<?php
							$total_marks = 0;
							$total_grade_point = 0;
							$total_subjects = 0;
							foreach ($marks as $mark):
						?>
							<tr>
								<td>
								<?php echo ucwords($this->db->get_where('subject' , array(
									'subject_id' => $mark['subject_id']
								))->row()->name);?>
								</td>
								<td>
								<?php echo $mark['mark_total'];?>
								</td>
								<td>
								<?php
									echo $mark['mark_obtained'];
									$total_marks += $mark['mark_obtained'];
									$total_subjects++;
								?>
								</td>
								<td>
								<?php
									$grade = get_grade($mark['mark_obtained']);
									echo ucwords($grade['name']);
									$total_grade_point += $grade['grade_point'];
								?>
								</td>
								<td>
								<?php echo ucwords($mark['comment']); ?>
								</td>
							</tr>
						<?php
							endforeach;
						?>
						</tbody>
						<tfoot>
							<tr>
								<th colspan="4" class="text-right"> Total Marks </th>
								<td> <?php echo $total_marks?> </td>
							</tr>
							<tr>
								<th colspan="4" class="text-right"> Average Grade Point </th>
								<td>
								<?php
									if($total_grade_point != 0 && $total_subjects != 0)
											echo round($total_grade_point / $total_subjects, 2);
								?>
								</td>
							</tr>
						</tfoot>
					</table>
					<?php
						else:
					?>
					<table class="table table-bordered table-striped">
						<thead>
							<tr>
								<th> No Exam Marks Available </th>
							</tr>
						</thead>
					</table>
					<?php
						endif;
					?>
				</div>
			</div>
			
			<!-- this row will not appear when printing -->
			<div class="row no-print mb-4">
				<div class="col-12">
					<a href="javascript:;" onClick="PrintElem('#sheet<?php echo $exam_id;?>')" class="btn btn-primary">
						<i class="fas fa-print"></i> Print Marksheet
					</a>
				</div>
			</div>
		</div>
		<hr>

		<script type="text/javascript">
		
			// print function
			function PrintElem(elem)
			{
				Popup($(elem).html());
			}
		
			function Popup(data)
			{
				var mywindow = window.open('', 'invoice', 'height=400,width=600');
				mywindow.document.write('<html><head><title>Exam Marksheet</title>');
				mywindow.document.write('<link rel="stylesheet" href="dist/css/raw.css">');
				mywindow.document.write('<link rel="stylesheet" href="plugins/fontawesome-free/css/all.css">');
				mywindow.document.write('</head><body >');
				mywindow.document.write(data);
				mywindow.document.write('</body></html>');
		
				var is_chrome = Boolean(mywindow.chrome);
				if (is_chrome) {
					setTimeout(function() {
						mywindow.print();
						mywindow.close();
		
						return true;
					}, 250);
				}
				else {
					mywindow.print();
					mywindow.close();
		
					return true;
				}
		
				return true;
			}
		
		</script>