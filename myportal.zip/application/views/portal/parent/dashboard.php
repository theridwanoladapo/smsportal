<?php
	$running_year = $this->db->get_where('settings', array('type' => 'running_year'))->row()->description;
?>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<!-- Content Header (Page header) -->
			<div class="content-header">
				<div class="container-fluid">
					<div class="row mb-2">
						<div class="col-sm-6">
						<h5 class="m-0 text-dark"> <?php echo $page_title; ?> </h5>
						</div><!-- /.col -->
						<div class="col-sm-6">
							<ol class="breadcrumb float-sm-right">
								<li class="breadcrumb-item"> Dashboard </li>
							</ol>
						</div><!-- /.col -->
					</div><!-- /.row -->
				</div><!-- /.container-fluid -->
			</div>
			<!-- /.content-header -->
		
			<!-- Main content -->
			<section class="content">
				<div class="container-fluid">
					
					<div class="row">
						
						<div class="col-md-8">
							<div class="card card-primary">
								<div class="card-header">
									<h5> Event Schedule </h5>
								</div>
								
								<div class="card-body p-0">
									<!-- THE CALENDAR -->
									<div id="calendar"></div>
								</div>
								<!-- /.card-body -->
							</div>
							<!-- /.card -->
						</div>
						<!-- /.col -->
						
					</div>
					<!-- /.row -->
					
				</div><!--/. container-fluid -->
			</section>
			<!-- /.content -->
		</div>
		<!-- /.content-wrapper -->
		
		<!-- Page specific script -->
		<script>
			$(function () {
				
				/* initialize the calendar
				-----------------------------------------------------------------*/
				//	Date for the calendar events (dummy data)
				var date = new Date()
				var d    = date.getDate(),
					m    = date.getMonth(),
					y    = date.getFullYear()
				
				var Calendar = FullCalendar.Calendar;
				var Draggable = FullCalendarInteraction.Draggable;
				
				var calendarEl = document.getElementById('calendar');
				
				var calendar = new Calendar(calendarEl, {
					plugins: [ 'bootstrap', 'interaction', 'dayGrid', 'timeGrid' ],
					header    : {
						left  : 'title',
						center: '',
						right : 'today prev,next'
					}
				});
				
				calendar.render();
				// $('#calendar').fullCalendar()
				
			})
		</script>