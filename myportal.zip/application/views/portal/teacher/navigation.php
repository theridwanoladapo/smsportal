		<!-- Main Sidebar Container -->
		<aside class="main-sidebar sidebar-light-primary elevation-4">
			<!-- Brand Logo -->
			<a href="" class="brand-link">
				<img src="uploads/logo.png" alt="AdminLTE Logo" class="brand-image elevation-3 bg-white">
				<span class="brand-text font-weight-light"> <?php echo ucwords($system_title); ?> </span>
			</a>
			
			<!-- Sidebar -->
			<div class="sidebar">
				<!-- Sidebar Menu -->
				<nav class="mt-2 mb-3">
					<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?teacher/dashboard" class="nav-link <?php if($page_name == 'dashboard') echo 'active'; ?>">
								<i class="nav-icon fas fa-tachometer-alt"></i>
								<p> Dashboard </p>
							</a>
						</li>
						<li class="nav-item has-treeview <?php if($page_name == 'student_information' ||
																$page_name == 'student_profile')
																	echo 'active menu-open'; ?>">
							<a href="javascript:;" class="nav-link <?php if($page_name == 'student_information' ||
																			$page_name == 'student_profile')
																				echo 'active'; ?>">
								<i class="nav-icon fas fa-users"></i>
								<p> Student <i class="fas fa-angle-left right"></i> </p>
							</a>
							<ul class="nav nav-treeview">
								<li class="nav-item">
									<a href="<?php echo base_url(); ?>index.php?teacher/student_information" class="nav-link <?php if($page_name == 'student_information' || $page_name == 'student_profile') echo 'active'; ?>">
										<i class="far fa-circle nav-icon"></i>
										<p>Student Information </p>
									</a>
								</li>
							</ul>
						</li>
						<li class="nav-item has-treeview <?php if($page_name == 'manage_attendance' ||
																$page_name == 'manage_attendance_view' ||
																$page_name == 'attendance_report' ||
																$page_name == 'attendance_report_view')
																	echo 'active menu-open'; ?>">
							<a href="javascript:;" class="nav-link <?php if($page_name == 'manage_attendance' ||
																			$page_name == 'manage_attendance_view' ||
																			$page_name == 'attendance_report' ||
																			$page_name == 'attendance_report_view')
																				echo 'active'; ?>">
								<i class="nav-icon fas fa-chart-area"></i>
								<p> Attendance <i class="fas fa-angle-left right"></i> </p>
							</a>
							<ul class="nav nav-treeview">
								<li class="nav-item">
									<a href="<?php echo base_url(); ?>index.php?teacher/manage_attendance" class="nav-link <?php if($page_name == 'manage_attendance' || $page_name == 'manage_attendance_view')	echo 'active'; ?>">
										<i class="far fa-circle nav-icon"></i>
										<p> Daily Attendance </p>
									</a>
								</li>
								<li class="nav-item">
									<a href="<?php echo base_url(); ?>index.php?teacher/attendance_report" class="nav-link <?php if($page_name == 'attendance_report' || $page_name == 'attendance_report_view')	echo 'active'; ?>">
										<i class="far fa-circle nav-icon"></i>
										<p> Attendance Report </p>
									</a>
								</li>
							</ul>
						</li>
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?teacher/subject" class="nav-link <?php if($page_name == 'subject') echo 'active'; ?>">
								<i class="fas fa-book-reader nav-icon"></i>
								<p> Subjects </p>
							</a>
						</li>
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?teacher/academic_syllabus" class="nav-link <?php if($page_name == 'academic_syllabus') echo 'active'; ?>">
								<i class="fas fa-bookmark nav-icon"></i>
								<p> Academic Syllabus </p>
							</a>
						</li>
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?teacher/study_material" class="nav-link <?php if($page_name == 'study_material') echo 'active'; ?>">
								<i class="fas fa-book-open nav-icon"></i>
								<p> Study Materials </p>
							</a>
						</li>
						<li class="nav-item has-treeview">
							<a href="<?php echo base_url(); ?>index.php?teacher/class_routine_view/" class="nav-link <?php if($page_name == 'class_routine_view') echo 'active'; ?>">
								<i class="nav-icon fas fa-table"></i>
								<p> Class Routine </p>
							</a>
						</li>
						<li class="nav-item has-treeview <?php if($page_name == 'marks_manage' ||
																$page_name == 'marks_manage_view' ||
																$page_name == 'question_paper')
																	echo 'active menu-open';?>">
							<a href="javascript:;" class="nav-link <?php if($page_name == 'marks_manage' ||
																			$page_name == 'marks_manage_view' ||
																			$page_name == 'question_paper')
																				echo 'active';?>">
								<i class="nav-icon fas fa-chart-area"></i>
								<p> Exam <i class="fas fa-angle-left right"></i> </p>
							</a>
							<ul class="nav nav-treeview">
								<li class="nav-item">
									<a href="<?php echo base_url(); ?>index.php?teacher/marks_manage" class="nav-link <?php if($page_name == 'marks_manage' || $page_name == 'marks_manage_view') echo 'active';?>">
										<i class="far fa-circle nav-icon"></i>
										<p> Manage Marks </p>
									</a>
								</li>
							</ul>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url(); ?>index.php?teacher/manage_profile" class="nav-link <?php if($page_name == 'manage_profile') echo 'active';?>">
								<i class="nav-icon fas fa-user-lock"></i>
								<p> Account </p>
							</a>
						</li>
					</ul>
				</nav>
				<!-- /.sidebar-menu -->
			</div>
			<!-- /.sidebar -->
		</aside>
		