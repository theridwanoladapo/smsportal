	<!-- Font Awesome -->
	<link rel="stylesheet" href="plugins/fontawesome-free/css/all.css">
	<!-- JQuery UI -->
	<!-- link rel="stylesheet" href="plugins/jquery-ui/jquery-ui.min.css">
	<!-- overlayScrollbars -->
	<link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
	<!-- iCheck for checkboxes and radio inputs -->
	<link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
	<!-- Toastr -->
	<link rel="stylesheet" href="plugins/toastr/toastr.min.css">
	<!-- Tempusdominus Bbootstrap 4 -->
	<link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
	<!-- Select2 -->
	<link rel="stylesheet" href="plugins/select2/css/select2.min.css">
	<link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
	<!-- Theme Style -->
	<link rel="stylesheet" href="plugins/bootstrap-fileinput/css/bootstrap-fileinput.css">
	<!-- DataTables -->
	<link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">
	<!-- Summernote -->
	<link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
	<!-- fullCalendar -->
	<link rel="stylesheet" href="plugins/fullcalendar/main.min.css">
	<link rel="stylesheet" href="plugins/fullcalendar-interaction/main.min.css">
	<link rel="stylesheet" href="plugins/fullcalendar-daygrid/main.min.css">
	<link rel="stylesheet" href="plugins/fullcalendar-timegrid/main.min.css">
	<link rel="stylesheet" href="plugins/fullcalendar-bootstrap/main.min.css">
	<!-- Theme Style -->
	<link rel="stylesheet" href="dist/css/raw.css">
	<!-- jQuery -->
	<script src="plugins/jquery/jquery.min.js"></script>
