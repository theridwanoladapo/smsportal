<?php
/*
|--------------------------------------------------------------------------
| URL Routing
|--------------------------------------------------------------------------
*/
$route['default_controller'] = 'install';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;