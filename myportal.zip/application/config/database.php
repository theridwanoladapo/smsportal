<?php
/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
*/
$dbconfig = array(
    'hostname'	=>	'db_host',
    'username'	=>	'db_user',
    'password'	=>	'db_pass',
    'dbname'	=>	'db_name',
	'charset'	=>	'utf8',
);