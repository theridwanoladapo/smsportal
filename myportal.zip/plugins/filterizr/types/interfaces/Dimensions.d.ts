/* iCheck plugin Flat skin
----------------------------------- */
.iche